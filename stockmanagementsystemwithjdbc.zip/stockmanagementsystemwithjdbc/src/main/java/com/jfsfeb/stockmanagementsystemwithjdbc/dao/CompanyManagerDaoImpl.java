package com.jfsfeb.stockmanagementsystemwithjdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import com.jfsfeb.stockmanagementsystemwithjdbc.dto.AdminBean;
import com.jfsfeb.stockmanagementsystemwithjdbc.dto.CompanyManagerBean;
import com.jfsfeb.stockmanagementsystemwithjdbc.dto.StockBean;
import com.jfsfeb.stockmanagementsystemwithjdbc.exceptions.StockException;
import com.jfsfeb.stockmanagementsystemwithjdbc.utility.JdbcUtilityForStock;



public class CompanyManagerDaoImpl implements CompanyManagerDao {

	JdbcUtilityForStock dataBaseConnector = new JdbcUtilityForStock();
	@Override
	public CompanyManagerBean managerLogin(String email, String password) {
		 CompanyManagerBean admin = new CompanyManagerBean();

			try (Connection connection = dataBaseConnector.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(dataBaseConnector.getSQLQuery("companyMangerLogin"))){
				
			        preparedStatement.setString(1, email);
					preparedStatement.setString(2, password);
					ResultSet resultSet = preparedStatement.executeQuery();
					if (resultSet.next()) {
						CompanyManagerBean bean = new CompanyManagerBean();
						bean.setId(resultSet.getInt("id"));
						bean.setName(resultSet.getString("name"));
						bean.setPhoneNumber(resultSet.getLong("phoneNumber"));
						bean.setMailId(resultSet.getString("mailId"));
						bean.setPassword(resultSet.getString("password"));
						bean.setRole(resultSet.getString("role"));
						
						return bean;
					} else {
						return null;
					}

				} catch (Exception e) {
					e.printStackTrace();
					return null;
				}

    }

	@Override
	public boolean changePassword(long mobile, String password) {
		try (Connection connection = dataBaseConnector.getConnection();
				 PreparedStatement preparedStatement = connection.prepareStatement(dataBaseConnector.getSQLQuery("changePassword"));) {
			   preparedStatement.setString(1, password);
				preparedStatement.setLong(2, mobile);
				
				int count = preparedStatement.executeUpdate();
				if (count != 0) {
					    return true;
				} else {
					return false;
				}
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
    }

	@Override
	public boolean addStock(StockBean stockBean) {
		try (Connection connection = dataBaseConnector.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(dataBaseConnector.getSQLQuery("addStocks"))){
				
				preparedStatement.setInt(1, stockBean.getId());
				preparedStatement.setString(2, stockBean.getCompanyName());
				preparedStatement.setInt(3, stockBean.getNoOfProducts());
				preparedStatement.setDouble(4, stockBean.getCost());
				preparedStatement.setString(5, stockBean.getTypeOfStock());
				
				int p=preparedStatement.executeUpdate();
				System.out.println(p);
				
			} catch (Exception e) {
				throw new StockException("stock already existed ,please add new stock");
			}
		
		return true;
	}

	@Override
	public boolean updateStockTypeById(int id, String type) {
		try (Connection connection = dataBaseConnector.getConnection();
				 PreparedStatement preparedStatement = connection.prepareStatement(dataBaseConnector.getSQLQuery("updateStockById"));) {

				preparedStatement.setInt(1,id );
				preparedStatement.setString(2, type);
				int count = preparedStatement.executeUpdate();
				if (count != 0) {
					    return true;
				} else {
					return false;
				}
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
     }

	@Override
	public boolean updateStockCostByName(String stockName, double cost) {
		try (Connection connection = dataBaseConnector.getConnection();
				 PreparedStatement preparedStatement = connection.prepareStatement(dataBaseConnector.getSQLQuery("updateStockByComName"));) {

				preparedStatement.setString(1,stockName );
				preparedStatement.setDouble(2, cost);
				int count = preparedStatement.executeUpdate();
				if (count != 0) {
					    return true;
				} else {
					return false;
				}
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
		
	}

	@Override
	public boolean updateStockCountByType(String type, int count) {
		try (Connection connection = dataBaseConnector.getConnection();
				 PreparedStatement preparedStatement = connection.prepareStatement(dataBaseConnector.getSQLQuery("updateStockCountByType"));) {

				preparedStatement.setString(1,type);
				preparedStatement.setInt(2, count);
				int count1 = preparedStatement.executeUpdate();
				if (count1 != 0) {
					    return true;
				} else {
					return false;
				}
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
		}

	@Override
	public boolean removeStock(int id) {
		try (Connection connection = dataBaseConnector.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(dataBaseConnector.getSQLQuery("removeStock"));) {

				preparedStatement.setInt(1, id);
				int count =preparedStatement.executeUpdate();
				if (count != 0) {
					return true;
				} else {
					return false;
				}

			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
      }

	@Override
	public List<StockBean> searchProductByName(String name) {
		
		try (Connection connection = dataBaseConnector.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(dataBaseConnector.getSQLQuery("searchProductByName"));) {

			preparedStatement.setString(1, name);
			ResultSet resultSet= preparedStatement.executeQuery();
			List<StockBean> beans = new ArrayList<StockBean>();
			while (resultSet.next()) {
				StockBean bean = new StockBean();
				bean.setId(resultSet.getInt("id"));
				bean.setCompanyName(resultSet.getString("companyName"));
				bean.setNoOfProducts(resultSet.getInt("noOfProducts"));
				bean.setCost(resultSet.getDouble("cost"));
				bean.setTypeOfStock(resultSet.getString("typeOfStock"));
				beans.add(bean);
			}
			return beans;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
    }

	@Override
	public List<StockBean> searchProductByType(String type) {
		try (Connection connection = dataBaseConnector.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(dataBaseConnector.getSQLQuery("searchProductByType"));) {

			preparedStatement.setString(1, type);
			ResultSet resultSet= preparedStatement.executeQuery();
			List<StockBean> beans = new ArrayList<StockBean>();
			while (resultSet.next()) {
				StockBean bean = new StockBean();
				bean.setId(resultSet.getInt("id"));
				bean.setCompanyName(resultSet.getString("companyName"));
				bean.setNoOfProducts(resultSet.getInt("noOfProducts"));
				bean.setCost(resultSet.getDouble("cost"));
				bean.setTypeOfStock(resultSet.getString("typeOfStock"));
				beans.add(bean);
			}
			return beans;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		
	}

	@Override
	public List<StockBean> getAllStcokInfo() {
		try (Connection connection = dataBaseConnector.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(dataBaseConnector.getSQLQuery("getAllStcokInfo"));) {
			ResultSet resultSet = preparedStatement.executeQuery();
			List<StockBean> beans = new ArrayList<StockBean>();
			while (resultSet.next()) {
				StockBean bean = new StockBean();
				bean.setId(resultSet.getInt("id"));
				bean.setCompanyName(resultSet.getString("companyName"));
				bean.setNoOfProducts(resultSet.getInt("noOfProducts"));
				bean.setCost(resultSet.getDouble("cost"));
				bean.setTypeOfStock(resultSet.getString("typeOfStock"));
				
				beans.add(bean);
			}
			return beans;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

}
