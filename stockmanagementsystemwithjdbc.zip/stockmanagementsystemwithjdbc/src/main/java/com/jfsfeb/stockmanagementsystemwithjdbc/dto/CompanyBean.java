package com.jfsfeb.stockmanagementsystemwithjdbc.dto;

import lombok.Data;

@Data
public class CompanyBean {

	private int companyId;
	private String compName;
	
}
