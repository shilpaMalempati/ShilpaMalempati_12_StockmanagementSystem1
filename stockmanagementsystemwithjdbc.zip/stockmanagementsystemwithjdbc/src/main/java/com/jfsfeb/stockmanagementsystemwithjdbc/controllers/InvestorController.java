package com.jfsfeb.stockmanagementsystemwithjdbc.controllers;

import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import com.jfsfeb.stockmanagementsystemwithjdbc.dto.AdminBean;
import com.jfsfeb.stockmanagementsystemwithjdbc.dto.BuyStockBean;
import com.jfsfeb.stockmanagementsystemwithjdbc.dto.StockBean;
import com.jfsfeb.stockmanagementsystemwithjdbc.dto.UserBean;
import com.jfsfeb.stockmanagementsystemwithjdbc.exceptions.StockException;
import com.jfsfeb.stockmanagementsystemwithjdbc.factory.StockFactory;
import com.jfsfeb.stockmanagementsystemwithjdbc.services.UserService;
import com.jfsfeb.stockmanagementsystemwithjdbc.services.UserServiceImpl;
import com.jfsfeb.stockmanagementsystemwithjdbc.validations.InputValidationsImpl;

@SuppressWarnings("unused")
public class InvestorController {
	public void investorController() {
		
        int regId = 0; 
		String regName = null; 
		long regMobile = 0;
		String regEmail = null;
		String regPassword = null;
		String regRole=null;

		int stockId = 0; 
		String stockCName = null;
		String stockType = null;
		int stcokNoOfProducts=0;
		double stockCost = 0.0;

		String loginMail=null;
		String loginPassword=null;

       System.out.println("<<<<>>>>--------welcome to investor blog-------<<<<>>>>");
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		UserService service1 = StockFactory.getInstanceOfUserService();
		InputValidationsImpl validation = new InputValidationsImpl();

		try {
			do {
				try {
					System.out.println("<<<<<----------------------------------->>>>>");
					System.out.println("Press 1 to Investor Register");
					System.out.println("Press 2 to investor Login");
					System.out.println("press 3 to exit");
					System.out.println("<<<<<----------------------------------->>>>>>");
					int choice = scanner.nextInt();
					switch (choice) {

					case 1:
						System.out.println("Enter ID :");
						regId = scanner.nextInt();
						System.out.println("Enter Name :");
						regName = scanner.next();
						System.out.println("Enter Mobile :");
						regMobile = scanner.nextLong();
						System.out.println("Enter Email :");
						regEmail = scanner.next();
						System.out.println("Enter Password :");
						regPassword = scanner.next();
						System.out.println("Enter role");
						regRole=scanner.next();
						UserBean bean1 = new UserBean();
						bean1.setId(regId);
						bean1.setName(regName);
						bean1.setPhoneNumber(regMobile);
						bean1.setMailId(regEmail);
						bean1.setPassword(regPassword);
						bean1.setRole(regRole);				

						boolean check = service1.registerUser(bean1);
						if(check) {
							System.out.println("Registered");
						} else {
							System.out.println("Email already exist");
						}


						break;

					case 2 :
						System.out.println("enter login mail");
						regEmail=scanner.next();
						System.out.println("Enter  password");
						regPassword = scanner.next();
                        try {
							@SuppressWarnings("unused")
							UserBean login = service1.loginUser(regEmail, regPassword);
							String s= new String(login.getName());
                            if(login!=null) {
							System.out.println("Logged in Successfully");
							System.out.println("<<<<------WELCOME "+s.toUpperCase()+"------>>>>");
							System.out.println();
							do {
								try {
									System.out.println("<<-------------------------------------------->>");
									System.out.println("press 1 : forgot password");
									System.out.println("press 2 : to update mail");
									System.out.println("Press 3 : to Search the stock by company name");
									System.out.println("Press 4 : to Search the stock by Type of stock");
									System.out.println("Press 5 : to Get the stock Information");
									System.out.println("Press 6 : to buy stock ");
									System.out.println("press 7 : to see all buy stock information");
									System.out.println("Press 8 : to signout");
									System.out.println("<<-------------------------------------------->>");

									int choice2 = scanner.nextInt();
									switch (choice2) {

									case 1 :
										System.out.println("Enter Mobile :");
										regMobile  = scanner.nextLong();
										System.out.println("Enter new pass word Password :");
										regPassword = scanner.next();

										if (regMobile == 0) {
											System.out.println("Enter the Valid phnumber");
										} else {

											Random random = new Random();
											int otp = random.nextInt(9999);
											System.out.println(otp<0?otp*-1:otp);
											System.out.println("please ,enter otp ");
											int typeOtp = scanner.nextInt();
											if(otp==typeOtp) {

												UserBean bean6 = new UserBean();
												bean6.setPhoneNumber(regMobile);
												bean6.setPassword(regPassword);
												boolean update = service1.changePassword(regMobile,regPassword);
												if (update) {
													System.out.println("password updated succesfully");
												} else {
													System.err.println("passwrod is not updated");
												}
											}else {
												System.err.println("otp mismatched");
											}
										}
										break;

									case 2 :
										System.out.println("Enter mobile number :");
										regMobile = scanner.nextLong();

										System.out.println("Enter Email :");
										regEmail = scanner.next();

										if (regMobile== 0) {
											System.out.println("Enter the Valid phnumber");
										} else {
											UserBean bean6 = new UserBean();
											bean6.setPhoneNumber(regMobile);
											bean6.setMailId(regEmail);
											boolean update = service1.updateProfile(regEmail, regMobile);
											if (update) {
												System.out.println("profile updated succesfully");
											} else {
												System.err.println("profile is not updated");
											}
										}
										break;

									case 3 :
										System.out.println("enter company name");
										String cName = scanner.next();

										List<StockBean> company = service1.searchProductByName(cName);
										if(company!=null) {
											System.out.println(String.format("%-5s %-20s %-20s %-20s %s", "Id",
													"company Name", "cost", "no of products", "type of product"));
											for (StockBean stockBean : company) {

												if (stockBean != null) {
													System.out.println(String.format("%-5s %-20s %-20s %-20s %s", stockBean.getId(),
															stockBean.getCompanyName(), stockBean.getCost(), stockBean.getNoOfProducts(), stockBean.getTypeOfStock()));
												} 
											}
										}else {
											System.err.println("No stocks are available with this company name!!");
										}
										break;

									case 4:
									
										System.out.println("Search the product by type :");
										String type = scanner.next();

										List<StockBean> beanType = service1.searchProductByType(type);
										if(beanType!=null) {

											System.out.println(String.format("%-5s %-20s %-20s %-20s %s", "Id",
													"cName", "no of products", "Cost", "type of stock"));

											for (StockBean bean : beanType) {	
												if (bean != null) {
													System.out.println(String.format("%-5s %-20s %-20s %-20s %s", bean.getId(),
															bean.getCompanyName(), bean.getNoOfProducts(), bean.getCost(), bean.getTypeOfStock()));
												}
											}
										}else {
											System.err.println("No stocks are available with this type!!");
										}
										break;


									case 5:
										List<StockBean> info = service1.getAllStcokInfo();
										System.out.println(String.format("%-5s %-20s %-20s %-20s %s",  "Id",
												"cName", "no of products", "Cost", "type of stock"));
										
										for (StockBean bean : info) {

											if (bean != null) {
												System.out.println(String.format("%-5s %-20s %-20s %-20s %s",bean.getId(),
														bean.getCompanyName(), bean.getNoOfProducts(), bean.getCost(), bean.getTypeOfStock()));
											} else {
												System.out.println("product information  is not present");
											}
										}
										
										break;
									case 6:
										System.out.println("Enter stock id");
										int bId = scanner.nextInt();
										StockBean stockBean = new  StockBean();
										stockBean.setId(bId);

										System.out.println("Enter user id");
										int userId = scanner.nextInt();
										UserBean userBean = new UserBean();
										userBean.setId(userId);
										
                                        BuyStockBean bean= new BuyStockBean();
										try {
										boolean request = service1.buyStock(userBean, stockBean);
											System.out.println("Buy stock information");
					
											if(request!=false) {
											       System.out.println("product added succefully to the cart");
											}else {
												System.err.println();
											}
										} catch (StockException e) {

											System.out.println("product is not available with this id !!");
										}
										break;


								    case 7:
								    	List<BuyStockBean> stockBean1 = service1.getAllBuyStockInfo();
								    	System.out.println(String.format("%-5s %-20s %-20s %-20s %-20s %-20s %s",  "Id",
												"companyName", "no of products", "Cost", "type of stock","user-id","user-name"));
									
										for (BuyStockBean bean11 : stockBean1) {

											if (bean11 != null) {
												
												System.out.println(String.format("%-5s %-20s %-20s %-20s %-20s %-20s %s",bean11.getStockId(),
														bean11.getCompanyName(), bean11.getNoOfProducts(), bean11.getCost(),
														bean11.getStockType(),bean11.getUserId(),bean11.getUserName()));
											} else {
												System.out.println("product information  is not present");
											}
										}
							
						                  break;
									
									case 8:
										MainController.mainController();
										break;

									default:
										System.err.println("please enter numeric positive choice between 1-8");
										break;
									}


								}catch (Exception e) {
						             System.err.println(e.getMessage());
									 investorController();
									 
								}
							}while(true);
                            }else {
                            	System.out.println("invalid credentilas...please try again!!");
                            }
						}catch (Exception e) {
							System.err.println(e.getMessage());
						}
						break;

					case 3 :
						 MainController.mainController();

					default : 
						System.err.println("plsease enter positive choice betweem 1-3");

					}
				}catch (InputMismatchException e) {
					System.err.println(" please,enter valid numeric choice between 1-3");
					investorController();
				}catch (StockException e) {
					System.err.println(e.getMessage());
					investorController();
				}

            }while(true);
		}catch (StockException e) {
			System.err.println(e.getMessage());
		}


	}

}
