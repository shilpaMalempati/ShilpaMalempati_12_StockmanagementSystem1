package com.jfsfeb.stockmanagementsystemwithjdbc.controllers;

public class StockMangementController {
	public static void main(String[] args) {
	
		MainController.mainController();
	}

}
