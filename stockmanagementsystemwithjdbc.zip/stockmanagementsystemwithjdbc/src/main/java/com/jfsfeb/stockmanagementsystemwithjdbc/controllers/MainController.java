package com.jfsfeb.stockmanagementsystemwithjdbc.controllers;

import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.jfsfeb.stockmanagementsystemwithjdbc.exceptions.StockException;
import com.jfsfeb.stockmanagementsystemwithjdbc.validations.InputValidationsImpl;

public class MainController {
	public static void mainController(){
	    @SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);

		do {
			try {
				System.out.println("<<<<<>>>>>-----------WELCOME TO STOCK MANAGEMNET SYSTEM----------<<<<<>>>>>");
				System.out.println("Press 1 to Admin Blog");
				System.out.println("press 2 companymanager blog");
				System.out.println("Press 3 to Investor Blog");
				System.out.println("-----------------------------------");

				int i = scanner.nextInt();
				
				if(Pattern.matches("^[0-9]", String.valueOf(i)) ) {
					
					switch(i) {

					case 1:
						AdminController adminController= new AdminController();
						adminController.adminController();
						break;

					case 2:
						CompanyManagerController managerContoller= new CompanyManagerController();
						managerContoller.companyManagerController();
						break;

					case 3:
						InvestorController controller= new InvestorController();
						controller.investorController();
						break;

					default :
						System.err.println("enter choice between 1-3");
					}
				}else {
					System.err.println("please, enter positive numbers only...!!");
				}
			}	catch (InputMismatchException e) {
				   System.err.println ("please, enter Numeric choice only...!!");
							 mainController();
			}
			
        }while(true);
		
	}



}
