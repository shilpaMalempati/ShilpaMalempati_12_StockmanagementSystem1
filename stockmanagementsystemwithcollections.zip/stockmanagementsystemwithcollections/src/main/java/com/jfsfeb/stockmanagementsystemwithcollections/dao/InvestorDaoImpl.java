package com.jfsfeb.stockmanagementsystemwithcollections.dao;

import java.util.LinkedList;

import java.util.List;

import com.jfsfeb.stockmanagementsystemwithcollections.dto.BuyStockBean;
import com.jfsfeb.stockmanagementsystemwithcollections.dto.StockBean;
import com.jfsfeb.stockmanagementsystemwithcollections.dto.InvestorBean;
import com.jfsfeb.stockmanagementsystemwithcollections.exceptions.StockException;
import com.jfsfeb.stockmanagementsystemwithcollections.repositories.StockRepository;



public class InvestorDaoImpl implements InvestorDao  {

	public boolean registerUser(InvestorBean user) {
		for(InvestorBean u : StockRepository.user) {
			if(u.getMailId().equals(user.getMailId())) {
				return false;
			}
		}
		StockRepository.user.add(user);
		return true;
	}


	public InvestorBean loginUser(String email, String password){
		for(InvestorBean user : StockRepository.user) {
			if((user.getMailId().equals(email) ) && (user.getPassword().equals(password))) {

				return user;
			}
		}
		throw new StockException("Invalid credentials");
	}



	public List<StockBean> searchProductByName(String name) {
		List<StockBean> searchList=new LinkedList<StockBean>();
		boolean searchUpdate=false;
		for(int i=0;i<=StockRepository.stock.size()-1;i++)
		{
			StockBean retrievedStock=StockRepository.stock.get(i);
			String retrievedStockName=retrievedStock.getCompanyName();
			if(name.equals(retrievedStockName))
			{
				searchList.add(retrievedStock);	
				searchUpdate=true;
				return searchList;
			}else
			{
				continue;
			}
		}
		return null;
	}


	public List<StockBean> searchProductByType(String type) {
		List<StockBean> searchList=new LinkedList<StockBean>();
		boolean searchUpdate=false;
		for(int i=0;i<=StockRepository.stock.size()-1;i++)
		{
			StockBean retrievedStock=StockRepository.stock.get(i);
			String retrievedStockType=retrievedStock.getTypeOfStock();
			if(type.equals(retrievedStockType))
			{
				searchList.add(retrievedStock);	
				searchUpdate=true;
				return searchList; 
			}else {
                     continue;
			}
			
		}
		return null;
		
}

	public List<StockBean> getAllStcokInfo() {
		return StockRepository.stock;
	}


	public BuyStockBean buyStock(InvestorBean user, StockBean stockBean) {
		boolean flag = false; 
		boolean	isRequestExists = false;
		BuyStockBean requestInfo = new BuyStockBean();
		InvestorBean userInfo2 = new InvestorBean();
		StockBean stockInfo2 = new StockBean();

		for (BuyStockBean requestInfo1 : StockRepository.request) {
			if (stockBean.getId() == requestInfo1.getStockInfo().getId()) {
				isRequestExists = true;
                System.out.println(requestInfo1.getStockInfo().getId());
			}
		}

		if (!isRequestExists) {
			for (InvestorBean userBean : StockRepository.user) {
				if (user.getId() == userBean.getId()) {
					for (StockBean stock : StockRepository.stock) {
						if (stockBean.getId() == stock.getId()) {
//							if(stockBean.getNoOfProducts()< stock.getNoOfProducts()) {
//								if(stockBean.getCost()<stock.getCost()) {
							          userInfo2 = userBean;
							          stockInfo2 = stock;
							          flag = true;
//								}
//							}
						}
					}
				}
			}
			if (flag == true) {
				requestInfo.setStockInfo(stockInfo2);
				requestInfo.setUserInfo(userInfo2);
				StockRepository.request.add(requestInfo);
				return requestInfo;
			}

		}

		throw new StockException("sorry!! you cannot Invest on stock");

	}


	@Override
	public boolean changePassword(long mobile, String password) {
		InvestorBean bean= new  InvestorBean();
		boolean updateStatus=false;
		for(int i=0;i<=StockRepository.user.size()-1;i++)
		{
			InvestorBean retrievedManager=StockRepository.user.get(i);

			long retrievedNum=retrievedManager.getPhoneNumber();
			if(mobile==retrievedNum)
			{  
				StockRepository.user.remove(i);
				bean.setPassword(password);
				bean.setPhoneNumber(mobile);
				bean.setId(retrievedManager.getId());
				bean.setName(retrievedManager.getName());
				bean.setMailId(retrievedManager.getMailId());

				updateStatus=true;

				break;
			}
		}
		StockRepository.user.add(bean);
		return updateStatus;
	}


	@Override
	public boolean updateProfile(String mail, long phnum) {
		InvestorBean bean= new InvestorBean();
		boolean updateStatus=false;
		for(int i=0;i<=StockRepository.user.size()-1;i++)
		{
			InvestorBean retrievedManager=StockRepository.user.get(i);

			long retrievedNum=retrievedManager.getPhoneNumber();
			if(phnum==retrievedNum)
			{  
				StockRepository.user.remove(i);
				bean.setMailId(mail);
				bean.setPhoneNumber(phnum);
				bean.setId(retrievedManager.getId());
				bean.setName(retrievedManager.getName());
				bean.setPassword(retrievedManager.getPassword());

				updateStatus=true;

				break;
			}
		}
		StockRepository.user.add(bean);
		return updateStatus;

	}


	@Override
	public List<BuyStockBean> getAllBuyStockInfo() {
		
		return StockRepository.request;
	}

}
