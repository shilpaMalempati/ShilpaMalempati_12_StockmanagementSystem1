package com.jfsfeb.stockmanagementsystemwithcollections.services;

import java.util.List;

import com.jfsfeb.stockmanagementsystemwithcollections.dto.BuyStockBean;
import com.jfsfeb.stockmanagementsystemwithcollections.dto.StockBean;
import com.jfsfeb.stockmanagementsystemwithcollections.dto.UserBean;


public interface UserService {
	boolean registerUser(UserBean user);
	UserBean loginUser(String email,String password);
	public BuyStockBean buyStock(UserBean user, StockBean stockBean);
	List<StockBean> searchProductByType(String type);
	List<StockBean> searchProductByName(String name);
	List<StockBean> getAllStcokInfo();
	List<BuyStockBean> getAllBuyStockInfo();
	boolean changePassword(long mobile, String password);
	boolean updateManager(String mail, long phNum);


}
