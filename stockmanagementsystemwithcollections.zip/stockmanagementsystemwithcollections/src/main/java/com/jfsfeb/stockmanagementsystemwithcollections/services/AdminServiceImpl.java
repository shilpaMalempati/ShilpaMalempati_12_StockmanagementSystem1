package com.jfsfeb.stockmanagementsystemwithcollections.services;

import java.util.List;
import com.jfsfeb.stockmanagementsystemwithcollections.dao.AdminDao;
import com.jfsfeb.stockmanagementsystemwithcollections.dto.AdminBean;
import com.jfsfeb.stockmanagementsystemwithcollections.dto.CompanyBean;
import com.jfsfeb.stockmanagementsystemwithcollections.dto.CompanyManagerBean;
import com.jfsfeb.stockmanagementsystemwithcollections.dto.StockBean;
import com.jfsfeb.stockmanagementsystemwithcollections.dto.InvestorBean;
import com.jfsfeb.stockmanagementsystemwithcollections.factory.StockFactory;
import com.jfsfeb.stockmanagementsystemwithcollections.validations.InputValidation;

import lombok.val;

public class AdminServiceImpl implements AdminService{
	
	private AdminDao dao = StockFactory.getInstanceOfAdminDao();
	
	InputValidation validation = StockFactory.getInstanceOfInvaInputValidation();

	@Override
	public boolean registerCompanyManger(CompanyManagerBean managerBean) {
		if(managerBean!=null){
			if(validation.validatedId(managerBean.getId())) {
				if(validation.validatedName(managerBean.getName())) {
					if(validation.validatedMobile(managerBean.getPhoneNumber())) {
						if(validation.validatedEmail(managerBean.getMailId())) {
							if(validation.validatedPassword(managerBean.getPassword())) {
								return dao.registerCompanyManger(managerBean);
							}
						}
					}
				}
			}
		}
		return false;
	}
	@Override
	public AdminBean adminLogin(String email, String password) {
		if(email!=null && password !=null) {
			if (validation.validatedEmail(email)) {
				if (validation.validatedPassword(password)) {
					return dao.adminLogin(email, password);
				}
			}
		}
		return null;
	        
   }

	@Override
	public boolean removeManager(int id) {
		if(id!=0) {
			if(validation.validatedId(id)) {
			         return dao.removeManager(id);
			}
		}
		return false;
	}

	@Override
	public boolean updateManager(String mail, long phNum) {
       if(mail!=null && phNum!=0) {
    	   if(validation.validatedEmail(mail)) {
    		   if(validation.validatedMobile(phNum)) {
    	               return dao.updateManager(mail, phNum);
    		   }
    	   }
       }
	       return false;
	}
	
	@Override
	public boolean addCompany(CompanyBean companyBean) {
		if(companyBean !=null) {
			if(validation.validatedId(companyBean.getCompanyId())) {
				if(validation.validatedName(companyBean.getCompName())) {
			                return dao.addCompany(companyBean);
				}
			}
		}
		return false;
		
	}

	@Override
	public boolean removeCompany(String companyName) {
		if(companyName!=null) {
			if(validation.validatedName(companyName)) {
			return dao.removeCompany(companyName);
			}
		}
		return false;
	}

	@Override
	public boolean updateCompany(String comName, int id) {
		if(comName != null && id!=0) {
			if(validation.validatedName(comName)) {
				if(validation.validatedId(id)) {
			          return dao.updateCompany(comName, id);
				}
			}
		}
		return false;
	}

	@Override
	public List<InvestorBean> showUsers() {
		return dao.showUsers();
	}
	
    @Override
	public List<CompanyBean> getAllCompanies() {
		return dao.getAllCompanies();
	}

	@Override
	public List<StockBean> getAllStcokInfo() {
		return dao.getAllStcokInfo();
	}

	@Override
	public List<CompanyManagerBean> getAllCompanyManagerInfo() {
		 return dao.getAllCompanyManagerInfo();
	}

	
}

