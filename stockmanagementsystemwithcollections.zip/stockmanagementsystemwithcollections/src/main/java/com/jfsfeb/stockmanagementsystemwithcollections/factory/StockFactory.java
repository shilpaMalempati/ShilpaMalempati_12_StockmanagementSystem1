package com.jfsfeb.stockmanagementsystemwithcollections.factory;

import com.jfsfeb.stockmanagementsystemwithcollections.dao.AdminDao;
import com.jfsfeb.stockmanagementsystemwithcollections.dao.AdminDaoImpl;
import com.jfsfeb.stockmanagementsystemwithcollections.dao.CompanyManagerDao;
import com.jfsfeb.stockmanagementsystemwithcollections.dao.CompanyManagerDaoImpl;
import com.jfsfeb.stockmanagementsystemwithcollections.dao.InvestorDao;
import com.jfsfeb.stockmanagementsystemwithcollections.dao.InvestorDaoImpl;
import com.jfsfeb.stockmanagementsystemwithcollections.services.AdminService;
import com.jfsfeb.stockmanagementsystemwithcollections.services.AdminServiceImpl;
import com.jfsfeb.stockmanagementsystemwithcollections.services.CompanyManagerService;
import com.jfsfeb.stockmanagementsystemwithcollections.services.CompanyManagerServiceImpl;
import com.jfsfeb.stockmanagementsystemwithcollections.services.InvestorService;
import com.jfsfeb.stockmanagementsystemwithcollections.services.InvestorServiceImpl;
import com.jfsfeb.stockmanagementsystemwithcollections.validations.InputValidation;
import com.jfsfeb.stockmanagementsystemwithcollections.validations.InputValidationsImpl;

public class StockFactory {
	public static AdminDao getInstanceOfAdminDao() {
		return new AdminDaoImpl();
	}
	
	public static CompanyManagerDao getInstanceOfComapnyMangerDao() {
		return new CompanyManagerDaoImpl();
	}
	
	public static InvestorDao getInstanceOfInvestorDao() {
		return new InvestorDaoImpl();
	}
	public static AdminService getInstanceOfAdminService() {
		return new AdminServiceImpl();
	}
	
	public static InvestorService getInstanceOfInvestorService() {
		return new InvestorServiceImpl();
	}
	
	public static  CompanyManagerService getInstanceOfCompanyMangerService() {
		return new CompanyManagerServiceImpl();
	}
	
	public static  InputValidation getInstanceOfInvaInputValidation() {
		return new InputValidationsImpl();
	}
   

}
