package com.jfsfeb.stockmanagementsystemwithcollections.controllers;

public class StockMangementController {
	public static void main(String[] args) {
	
		MainController.mainController();
	}

}
