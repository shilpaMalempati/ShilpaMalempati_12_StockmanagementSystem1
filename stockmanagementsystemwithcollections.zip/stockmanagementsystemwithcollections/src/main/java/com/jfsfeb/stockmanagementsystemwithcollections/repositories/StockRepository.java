package com.jfsfeb.stockmanagementsystemwithcollections.repositories;

import java.util.ArrayList;
import java.util.List;

import com.jfsfeb.stockmanagementsystemwithcollections.dto.AdminBean;
import com.jfsfeb.stockmanagementsystemwithcollections.dto.BuyStockBean;
import com.jfsfeb.stockmanagementsystemwithcollections.dto.CompanyBean;
import com.jfsfeb.stockmanagementsystemwithcollections.dto.CompanyManagerBean;
import com.jfsfeb.stockmanagementsystemwithcollections.dto.StockBean;
import com.jfsfeb.stockmanagementsystemwithcollections.dto.InvestorBean;

@SuppressWarnings("unused")
public class StockRepository {
	
	public static final List<StockBean> stock = new ArrayList<StockBean>(); 
	public static final List<AdminBean> admin = new ArrayList<AdminBean>();
	public static final List<InvestorBean> user = new ArrayList<InvestorBean>();
	public static final List<BuyStockBean> request = new ArrayList<BuyStockBean>();
	public static final List<CompanyBean> company = new ArrayList<CompanyBean>();
	public static final List<CompanyManagerBean> companyManager = new ArrayList<CompanyManagerBean>();


	public static void addToDB() {

	   AdminBean bean = new AdminBean();
	   bean.setId(22);
	   bean.setMailId("shilpa123@gmail.com");
	   bean.setName("shilpa");
	   bean.setPassword("Shilpa@123");
	   bean.setPhoneNumber(9876543211L);
       admin.add(bean);
       
       AdminBean bean1 = new AdminBean();
	   bean1.setId(33);
	   bean1.setMailId("harsha123@gmail.com");
	   bean1.setName("harsha");
	   bean1.setPassword("Harsha@123");
	   bean1.setPhoneNumber(9876543212L);
       admin.add(bean1);
       
       
       InvestorBean userBean= new InvestorBean();
       userBean.setId(11);
       userBean.setMailId("spurth123@gmail.com");
       userBean.setName("spurthi");
       userBean.setPassword("Spurthi@123");
       userBean.setPhoneNumber(9876543213L);
       user.add(userBean);
       
       InvestorBean userBean1= new InvestorBean();
       userBean1.setId(10);
       userBean1.setMailId("rani123@gmail.com");
       userBean1.setName("rani");
       userBean1.setPassword("55");
       userBean1.setPhoneNumber(9876543214L);
       user.add(userBean1);
       
       CompanyManagerBean managerBean = new CompanyManagerBean();
       managerBean.setId(33);
       managerBean.setMailId("yams123@gmail.com");
       managerBean.setName("yamini");
       managerBean.setPassword("Yams@123");
       managerBean.setPhoneNumber(9876543215L);
       companyManager.add(managerBean);
       
       CompanyManagerBean managerBean1 = new CompanyManagerBean();
       managerBean1.setId(44);
       managerBean1.setMailId("raja123@gmail.com");
       managerBean1.setName("raja");
       managerBean1.setPassword("Raja@123");
       managerBean1.setPhoneNumber(9876543216L);
       companyManager.add(managerBean1);
       
       CompanyBean companyBean = new CompanyBean();
       companyBean.setCompanyId(32);
       companyBean.setCompName("micromax");
       company.add(companyBean);
       
       CompanyBean companyBean1 = new CompanyBean();
       companyBean1.setCompanyId(34);
       companyBean1.setCompName("samsung");
       company.add(companyBean1);

       
       StockBean stockBean = new StockBean();
       stockBean.setId(55);
       stockBean.setCompanyName("micromax");
       stockBean.setCost(9000.0);
       stockBean.setNoOfProducts(20);
       stockBean.setTypeOfStock("mobile");
       stock.add(stockBean);
       
       StockBean stockBean1 = new StockBean();
       stockBean1.setId(66);
       stockBean1.setCompanyName("samsung");
       stockBean1.setCost(10000.0);
       stockBean1.setNoOfProducts(34);
       stockBean1.setTypeOfStock("headphones");
       stock.add(stockBean1);
       
       BuyStockBean buyStockBean = new  BuyStockBean();
       buyStockBean.setStockInfo(stockBean1);
       buyStockBean.setUserInfo(userBean1);
       request.add(buyStockBean);
       
   }
}
