package com.jfsfeb.stockmanagementsystemwithcollections.dto;


import lombok.Data;

@Data

public class BuyStockBean {
	
	private StockBean stockInfo;
	private InvestorBean userInfo;

}
