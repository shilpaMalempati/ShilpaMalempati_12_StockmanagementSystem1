package com.jfsfeb.stockmanagementsystemwithcollections.services;

import java.util.List;
import com.jfsfeb.stockmanagementsystemwithcollections.dao.InvestorDao;
import com.jfsfeb.stockmanagementsystemwithcollections.dto.BuyStockBean;
import com.jfsfeb.stockmanagementsystemwithcollections.dto.StockBean;
import com.jfsfeb.stockmanagementsystemwithcollections.dto.InvestorBean;
import com.jfsfeb.stockmanagementsystemwithcollections.factory.StockFactory;
import com.jfsfeb.stockmanagementsystemwithcollections.validations.InputValidation;

import lombok.val;

public class InvestorServiceImpl implements InvestorService {
	
    InputValidation validation = StockFactory.getInstanceOfInvaInputValidation();
    private InvestorDao dao = StockFactory.getInstanceOfInvestorDao();

	@Override
	public boolean registerUser(InvestorBean user) {
       if(user != null){
    	   if(validation.validatedId(user.getId())) {
				if(validation.validatedName(user.getName())) {
					if(validation.validatedMobile(user.getPhoneNumber())) {
						if(validation.validatedEmail(user.getMailId())) {
							if(validation.validatedPassword(user.getPassword())) {
								return dao.registerUser(user);
							}
						}
					}
				}
			}
       }
	return false;
	}

	@Override
	public InvestorBean loginUser(String email, String password) {
		if(email!=null && password != null ) {
			if(validation.validatedEmail(email)) {
				if(validation.validatedPassword(password)) {
					return dao.loginUser(email, password);
				}			
			}
		}
		return null;
	}

	@Override
	public BuyStockBean buyStock(InvestorBean user, StockBean stockBean) {
		if(user != null && stockBean != null) {
			if(validation.validatedId(stockBean.getId())) {
				if(validation.validatedId(user.getId())) {
					return dao.buyStock(user,stockBean);
				}
			}
		}
		return null;
	}

	@Override
	public List<StockBean> searchProductByType(String type) {
		if(type != null) {
			if(validation.validatedName(type)) {
				return dao.searchProductByType(type);
			}
		}
		return null;
		
	}

	@Override
	public List<StockBean> searchProductByName(String name) {
		if(name != null) {
			if(validation.validatedName(name)) {
				return dao.searchProductByName( name);
			}
		}
		return null;
	}

	@Override
	public List<StockBean> getAllStcokInfo() {

		return dao.getAllStcokInfo();
	}

	@Override
	public boolean changePassword(long mobile, String password) {
		if(mobile!=0 && password != null) {
			if(validation.validatedMobile(mobile)) {
				if(validation.validatedPassword(password)) {
			         return dao.changePassword( mobile,  password);
				}
			}
		}
		return false;
	}

	@Override
	public boolean updateProfile(String mail, long phNum) {
	 if(mail!= null && phNum !=0) {
		 if(validation.validatedEmail(mail)) {
			 if(validation.validatedMobile(phNum)) {
		        return dao.updateProfile(mail, phNum);
			 }
		 }
	 }
	return false;
	}

	@Override
	public List<BuyStockBean> getAllBuyStockInfo() {
		
		return dao.getAllBuyStockInfo();
	}





}
