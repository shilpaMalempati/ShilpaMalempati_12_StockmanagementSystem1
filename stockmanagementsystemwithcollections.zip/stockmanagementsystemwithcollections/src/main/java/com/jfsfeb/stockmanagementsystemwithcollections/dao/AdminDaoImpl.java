package com.jfsfeb.stockmanagementsystemwithcollections.dao;

import java.util.LinkedList;

import java.util.List;

import com.jfsfeb.stockmanagementsystemwithcollections.dto.AdminBean;
import com.jfsfeb.stockmanagementsystemwithcollections.dto.CompanyBean;
import com.jfsfeb.stockmanagementsystemwithcollections.dto.CompanyManagerBean;
import com.jfsfeb.stockmanagementsystemwithcollections.dto.StockBean;
import com.jfsfeb.stockmanagementsystemwithcollections.dto.InvestorBean;
import com.jfsfeb.stockmanagementsystemwithcollections.exceptions.StockException;
import com.jfsfeb.stockmanagementsystemwithcollections.repositories.StockRepository;


public class AdminDaoImpl implements AdminDao{

	@Override
	public boolean registerCompanyManger(CompanyManagerBean managerBean) {
		for(CompanyManagerBean ad :StockRepository.companyManager) {
			if(ad.getMailId().equals(managerBean.getMailId())) {
				return false;
			}
		}
		StockRepository.companyManager.add(managerBean);
		return true;
	}

	@Override
	public AdminBean adminLogin(String email, String password) {
		for(AdminBean admin : StockRepository.admin) {
			if((admin.getMailId().equals(email) ) && (admin.getPassword().equals(password))) {

				return admin;
			}
		}
		throw new StockException("Invalid credentials");
		

	}

	@Override
	public boolean removeManager(int id) {
		boolean removeStatus=false;
		for(int i=0;i<=StockRepository.companyManager.size()-1;i++)
		{
			CompanyManagerBean retrievedManager=StockRepository.companyManager.get(i);
			int retrievedId=retrievedManager.getId();
			if(id==retrievedId)
			{
				removeStatus=true;
				StockRepository.companyManager.remove(i);
				break;
			}
		}
		return removeStatus;
	}

	@Override
	public boolean updateManager(String mail, long phNum) {

		CompanyManagerBean managerBean = new CompanyManagerBean();
		boolean updateStatus=false;
		for(int i=0;i<=StockRepository.companyManager.size()-1;i++)
		{
			CompanyManagerBean retrievedManager=StockRepository.companyManager.get(i);
            String name=retrievedManager.getName();
            String password = retrievedManager.getPassword();
            int id = retrievedManager.getId();
			long retrievedNum=retrievedManager.getPhoneNumber();
			if(phNum==retrievedNum)
			{  
				StockRepository.companyManager.remove(i);
				managerBean.setMailId(mail);
				managerBean.setPhoneNumber(phNum);
				managerBean.setId(id);
				managerBean.setName(name);
				managerBean.setPassword(password);

				updateStatus=true;
				StockRepository.companyManager.add(managerBean);
				return updateStatus;
			}
		}
		
		return false;

	}


	@Override
	public boolean updateCompany(String comName, int id) {
		CompanyBean companyBean = new CompanyBean();
		boolean updateStatus=false;
		for(int i=0;i<=StockRepository.company.size()-1;i++)
		{
			CompanyBean  retrievedCName=StockRepository.company.get(i);
			String retrievedCName1=retrievedCName.getCompName();
			if(comName.equals(retrievedCName1))
			{
				StockRepository.company.remove(i);
				companyBean.setCompanyId(id);
				companyBean.setCompName(comName);
				updateStatus=true;
				break;

			}
		}
		StockRepository.company.add(companyBean);
		return updateStatus ;

	}

	@Override
	public List<InvestorBean> showUsers() {
		List<InvestorBean> usersList = new LinkedList<InvestorBean>();
		for (InvestorBean userBean : StockRepository.user) {

			userBean.getId();
			userBean.getName();
			userBean.getMailId();
			userBean.getPassword();
			userBean.getPhoneNumber();
			usersList.add(userBean);

		}
		return usersList;
	}

	@Override
	public List<CompanyBean> getAllCompanies() {
		List<CompanyBean> usersList = new LinkedList<CompanyBean>();
		for (CompanyBean companyBean : StockRepository.company) {

			companyBean.getCompanyId();
			companyBean.getCompName();
			usersList.add(companyBean);

		}
		return usersList;

	}

	@Override
	public List<StockBean> getAllStcokInfo() {

		return StockRepository.stock;
	}

	@Override
	public List<CompanyManagerBean> getAllCompanyManagerInfo() {
		List<CompanyManagerBean> usersList = new LinkedList<CompanyManagerBean>();
		for (CompanyManagerBean managerBean : StockRepository.companyManager) {

			managerBean.getId();
			managerBean.getName();
			managerBean.getMailId();
			managerBean.getPassword();
			managerBean.getPhoneNumber();
			usersList.add(managerBean);

		}
		return usersList;
	}

	@Override
	public boolean addCompany(CompanyBean companyBean) {
		for(CompanyBean b : StockRepository.company) {
			if(b.getCompanyId()==companyBean.getCompanyId()) {
				return false;
			}
		}
		StockRepository.company.add(companyBean);
		return true;

	}

	
	@Override
	public boolean removeCompany(String companyName) {
		boolean removeStatus=false;
		for(int i=0;i<=StockRepository.company.size()-1;i++)
		{
			CompanyBean retrievedCompany=StockRepository.company.get(i);
			String retrievedcomName=retrievedCompany.getCompName();
			if(companyName.equals(retrievedcomName))
			{
				removeStatus=true;
				StockRepository.company.remove(i);
				break;
			}
		}
		return removeStatus;
	}

}
