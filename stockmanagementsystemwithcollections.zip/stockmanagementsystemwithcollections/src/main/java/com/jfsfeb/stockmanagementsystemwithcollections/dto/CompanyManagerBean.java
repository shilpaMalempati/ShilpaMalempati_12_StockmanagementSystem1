package com.jfsfeb.stockmanagementsystemwithcollections.dto;

import lombok.Data;

@Data
public class CompanyManagerBean {
	 private int id;
	 private String name;
	 private long phoneNumber;
	 private String mailId;
	 private String password;
	 private String role;

	}
