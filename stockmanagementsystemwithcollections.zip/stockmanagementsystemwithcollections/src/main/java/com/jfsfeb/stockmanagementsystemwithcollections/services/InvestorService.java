package com.jfsfeb.stockmanagementsystemwithcollections.services;

import java.util.List;

import com.jfsfeb.stockmanagementsystemwithcollections.dto.BuyStockBean;
import com.jfsfeb.stockmanagementsystemwithcollections.dto.StockBean;
import com.jfsfeb.stockmanagementsystemwithcollections.dto.InvestorBean;


public interface InvestorService {
	boolean registerUser(InvestorBean user);
	InvestorBean loginUser(String email,String password);
	public BuyStockBean buyStock(InvestorBean user, StockBean stockBean);
	List<StockBean> searchProductByType(String type);
	List<StockBean> searchProductByName(String name);
	List<StockBean> getAllStcokInfo();
	List<BuyStockBean> getAllBuyStockInfo();
	boolean changePassword(long mobile, String password);
	boolean updateProfile(String mail, long phNum);


}
