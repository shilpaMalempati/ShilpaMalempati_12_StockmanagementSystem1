package com.jfsfeb.stockmanagementsystemwithcollections.dto;

import lombok.Data;
import lombok.ToString;


@Data
public class StockBean {
	 private int id;
	 private String companyName;
	 private int  noOfProducts;
	 private double  cost;
	 private String typeOfStock;
	 
	
}
