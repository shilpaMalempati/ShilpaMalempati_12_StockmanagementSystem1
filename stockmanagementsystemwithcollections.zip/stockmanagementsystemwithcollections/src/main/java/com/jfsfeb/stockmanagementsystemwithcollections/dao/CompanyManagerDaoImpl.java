package com.jfsfeb.stockmanagementsystemwithcollections.dao;

import java.util.LinkedList;

import java.util.List;

import com.jfsfeb.stockmanagementsystemwithcollections.dto.AdminBean;
import com.jfsfeb.stockmanagementsystemwithcollections.dto.CompanyManagerBean;
import com.jfsfeb.stockmanagementsystemwithcollections.dto.StockBean;
import com.jfsfeb.stockmanagementsystemwithcollections.exceptions.StockException;
import com.jfsfeb.stockmanagementsystemwithcollections.repositories.StockRepository;



public class CompanyManagerDaoImpl implements CompanyManagerDao {

	@Override
	public CompanyManagerBean managerLogin(String email, String password) {
		for(CompanyManagerBean comBean : StockRepository.companyManager) {
			if((comBean.getMailId().equals(email) ) && (comBean.getPassword().equals(password))) {

				return comBean;
			}
		}
		throw new StockException("Invalid credentials");

	}

	@Override
	public boolean changePassword(long mobile, String password) {
		CompanyManagerBean bean= new  CompanyManagerBean();
		boolean updateStatus=false;
		for(int i=0;i<=StockRepository.companyManager.size()-1;i++)
		{
			CompanyManagerBean retrievedManager=StockRepository.companyManager.get(i);
            long retrievedNum=retrievedManager.getPhoneNumber();
			if(mobile==retrievedNum)
			{  
				StockRepository.companyManager.remove(i);
				bean.setPassword(password);
				bean.setPhoneNumber(mobile);
                StockRepository.companyManager.add(bean);
                updateStatus=true;

				return updateStatus;
			}
		}
		return false;
	}

	@Override
	public boolean addStock(StockBean stockBean) {
		for(StockBean b : StockRepository.stock) {
			if(b.getId()==stockBean.getId()) {
				return false;
			}
		}
		StockRepository.stock.add(stockBean);
		return true;
	}

	@Override
	public boolean updateStockTypeById(int id, String type) {
		StockBean bean6 = new StockBean();
		boolean updateStatus=false;
		for(int i=0;i<=StockRepository.stock.size()-1;i++)
		{
			StockBean retrievedId=StockRepository.stock.get(i);
			int retrievedId1=retrievedId.getId();
			if(id==(retrievedId1))
			{
				StockRepository.stock.remove(i);
				bean6.setId(id);
				bean6.setTypeOfStock(type);
				bean6.setCompanyName(retrievedId.getCompanyName());
				bean6.setCost(retrievedId.getCost());
				bean6.setNoOfProducts(retrievedId.getNoOfProducts());
				updateStatus=true;
				break;

			}
		}
		StockRepository.stock.add(bean6);
		return updateStatus ;

	}

	@Override
	public boolean updateStockCostByName(String stockName, double cost) {
		StockBean bean6 = new StockBean();
		boolean updateStatus=false;
		for(int i=0;i<=StockRepository.stock.size()-1;i++)
		{
			StockBean retrievedSName=StockRepository.stock.get(i);
			String retrievedSName1=retrievedSName.getCompanyName();
			if(stockName.equals(retrievedSName1))
			{
				StockRepository.stock.remove(i);
				bean6.setCompanyName(stockName);
				bean6.setCost(cost);
				bean6.setId(retrievedSName.getId());
				bean6.setNoOfProducts(retrievedSName.getNoOfProducts());
				bean6.setTypeOfStock(retrievedSName.getTypeOfStock());
				updateStatus=true;
				StockRepository.stock.add(bean6);
				return updateStatus ;
			}else {
				continue;
			}
			
		}
		return false;

	}

	@Override
	public boolean updateStockCountByType(String type, int count) {
		StockBean bean6 = new StockBean();
		boolean updateStatus=false;
		for(int i=0;i<=StockRepository.stock.size()-1;i++)
		{
			StockBean retrievedType=StockRepository.stock.get(i);
			String retrievedType1=retrievedType.getTypeOfStock();
			if(type.equals(retrievedType1))
			{
				StockRepository.stock.remove(i);
				bean6.setTypeOfStock(type);
				bean6.setCost(count);
				bean6.setCompanyName(retrievedType.getCompanyName());
				bean6.setId(retrievedType.getId());
				bean6.setNoOfProducts(retrievedType.getNoOfProducts());
				updateStatus=true;
				break;

			}
		}
		StockRepository.stock.add(bean6);
		return updateStatus ;
	}

	@Override
	public boolean removeStock(int id) {
		boolean removeStatus=false;
		for(int i=0;i<=StockRepository.stock.size()-1;i++)
		{
			StockBean retrievedStoock=StockRepository.stock.get(i);
			int retrievedId=retrievedStoock.getId();
			if(id==retrievedId)
			{
				
				StockRepository.stock.remove(i);
				removeStatus=true;
                return removeStatus;
				
			}else {
				continue;
			}
		}
		return false;
		

	}

	@Override
	public List<StockBean> searchProductByName(String name) {
		List<StockBean> searchList=new LinkedList<StockBean>();
		boolean searchUpdate=false;
		for(int i=0;i<=StockRepository.stock.size()-1;i++)
		{
			StockBean retrievedStock=StockRepository.stock.get(i);
			String retrievedProductName=retrievedStock.getCompanyName();
			if(name.equals(retrievedProductName))
			{
				searchList.add(retrievedStock);	
				searchUpdate=true;
                return searchList;
			}
			else
			{
				continue;
			}
		}
	      	return null;	
	}

	@Override
	public List<StockBean> searchProductByType(String Type) {
		List<StockBean> searchList=new LinkedList<StockBean>();
		boolean searchUpdate=false;
		for(int i=0;i<=StockRepository.stock.size()-1;i++)
		{
			StockBean retrievedStock=StockRepository.stock.get(i);
			String retrievedType=retrievedStock.getTypeOfStock();
			if(Type.equals(retrievedType))
			{
				searchList.add(retrievedStock);	
				searchUpdate=true;
				return searchList;
			}else
			{
				continue;				
		    }
		}
		return null;
	}

	@Override
	public List<StockBean> getAllStcokInfo() {
		return StockRepository.stock;
	}

}
