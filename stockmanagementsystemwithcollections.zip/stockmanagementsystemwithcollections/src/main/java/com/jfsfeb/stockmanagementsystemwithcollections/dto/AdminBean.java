package com.jfsfeb.stockmanagementsystemwithcollections.dto;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class AdminBean {
    private	int id;
	private String name;
	private long phoneNumber;
	private String mailId;
	private String password;
	private String role;
//Default Constructor

	
}
