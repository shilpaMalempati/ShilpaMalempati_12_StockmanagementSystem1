package com.jfsfeb.stockmanagementsystemwithcollections.services;

import java.util.List;

import com.jfsfeb.stockmanagementsystemwithcollections.dto.AdminBean;
import com.jfsfeb.stockmanagementsystemwithcollections.dto.CompanyManagerBean;
import com.jfsfeb.stockmanagementsystemwithcollections.dto.StockBean;

public interface CompanyManagerService {
	CompanyManagerBean managerLogin(String email,String password);
	boolean changePassword(long mobile,String password);
	boolean addStock(StockBean stockBean);
	boolean updateStockTypeById(int id,String type);
	boolean updateStockCostByName(String stockName,double cost);
	boolean updateStockCountByType(String type,int count);
	boolean removeStock(int id);
    List<StockBean> searchProductByName(String name);
	List<StockBean> searchProductByType(String type);
	List<StockBean> getAllStcokInfo();
}
