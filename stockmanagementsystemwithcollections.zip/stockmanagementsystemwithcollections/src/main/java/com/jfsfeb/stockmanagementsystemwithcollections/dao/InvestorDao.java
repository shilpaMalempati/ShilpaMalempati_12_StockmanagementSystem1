package com.jfsfeb.stockmanagementsystemwithcollections.dao;

import java.util.List;

import com.jfsfeb.stockmanagementsystemwithcollections.dto.BuyStockBean;
import com.jfsfeb.stockmanagementsystemwithcollections.dto.StockBean;
import com.jfsfeb.stockmanagementsystemwithcollections.dto.InvestorBean;


public interface InvestorDao {
	boolean registerUser(InvestorBean user);
	InvestorBean loginUser(String email,String password);
	BuyStockBean buyStock(InvestorBean user, StockBean stockBean);
	List<StockBean> searchProductByType(String type);
	List<StockBean> searchProductByName(String name);
	List<StockBean> getAllStcokInfo();
	boolean changePassword(long mobile, String password);
	boolean updateProfile(String mail, long phNum);
	List<BuyStockBean> getAllBuyStockInfo();


}
