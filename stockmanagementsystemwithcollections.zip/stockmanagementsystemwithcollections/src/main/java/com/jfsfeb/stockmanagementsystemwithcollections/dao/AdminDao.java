package com.jfsfeb.stockmanagementsystemwithcollections.dao;

import java.util.List;

import com.jfsfeb.stockmanagementsystemwithcollections.dto.AdminBean;
import com.jfsfeb.stockmanagementsystemwithcollections.dto.CompanyBean;
import com.jfsfeb.stockmanagementsystemwithcollections.dto.CompanyManagerBean;
import com.jfsfeb.stockmanagementsystemwithcollections.dto.StockBean;
import com.jfsfeb.stockmanagementsystemwithcollections.dto.InvestorBean;

public interface AdminDao {
	boolean registerCompanyManger(CompanyManagerBean managerBean);
	AdminBean adminLogin(String email,String password);
	boolean removeManager(int id);
	boolean updateManager(String mail, long phNum);
	boolean addCompany(CompanyBean companyBean);
	boolean updateCompany(String comName,int id);
	boolean removeCompany(String compName);
	
	List<InvestorBean> showUsers();
	List<CompanyBean> getAllCompanies();
	List<StockBean> getAllStcokInfo();
	List<CompanyManagerBean> getAllCompanyManagerInfo();
	
	
	
}
