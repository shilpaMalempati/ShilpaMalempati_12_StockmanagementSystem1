package com.jfsfeb.stockmanagementsystemwithcollections.dto;

import lombok.Data;

@Data
public class CompanyBean {

	private int companyId;
	private String compName;
	
}
