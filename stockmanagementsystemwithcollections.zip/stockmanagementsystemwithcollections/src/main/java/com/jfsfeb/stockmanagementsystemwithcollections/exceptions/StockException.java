package com.jfsfeb.stockmanagementsystemwithcollections.exceptions;

public class StockException extends RuntimeException{

	public StockException(String msg) {
	         super(msg);
	}
    
}
