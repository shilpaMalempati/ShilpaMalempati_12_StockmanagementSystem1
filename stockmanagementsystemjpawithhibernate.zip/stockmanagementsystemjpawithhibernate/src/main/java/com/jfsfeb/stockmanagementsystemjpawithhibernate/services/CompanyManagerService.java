package com.jfsfeb.stockmanagementsystemjpawithhibernate.services;

import java.util.List;

import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.AdminBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.CompanyManagerBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.StockBean;

public interface CompanyManagerService {
	CompanyManagerBean managerLogin(String email,String password);
	boolean changePassword(long mobile,String password);
	boolean addStock(StockBean stockBean);
	boolean updateStockTypeById(int id,String type);
	boolean updateStockCostById(int id,double cost);
	boolean updateStockCountById(int id,int count);
	boolean removeStock(int id);
    List<StockBean> searchProductByName(String name);
	List<StockBean> searchProductByType(String type);
	List<StockBean> getAllStcokInfo();
}
