package com.jfsfeb.stockmanagementsystemjpawithhibernate.controllers;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.AdminBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.CompanyBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.CompanyManagerBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.StockBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.UserBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.exceptions.StockException;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.factory.StockFactory;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.services.AdminService;

@SuppressWarnings("unused")
public class AdminController {
	public void adminController() {
		int regId = 0; 
		String regName = null; 
		long regMobile = 0;
		String regEmail = null;
		String regPassword = null;
		String regRole= null;

		int stockId = 0; 
		String stockCName = null;
		String stockType = null;
		int stcokNoOfProducts=0;
		double stockCost = 0.0;

		String loginMail=null;
		String loginPassword=null;

		int companyId = 0;
		String companyName=null;

		@SuppressWarnings("resource")
		Scanner scanner= new Scanner(System.in);

		AdminService service = StockFactory.getInstanceOfAdminService();
		
		System.out.println("<<<<>>>>-------------welcome to admin blog,please login------------<<<<<>>>>");
		System.out.println();
		System.out.println("Enter email for login :");
		loginMail = scanner.next();
		System.out.println("Enter Password :");
		loginPassword = scanner.next();
		System.out.println();

		try {
			AdminBean login = service.adminLogin(loginMail,loginPassword);
			String s= new String(login.getName());
			if(login!=null) {
			System.out.println("You have logged in successfully");
			System.out.println();
			System.out.println(" <<<<<>>>>>-------------WELCOME "+s.toUpperCase()+"------------<<<<>>>>>");
			System.out.println();
			System.out.println("Now you can perform the following operations:-");
			do{
				try {
					System.out.println("<<<<<<----------------------------------->>>>>>");
					System.out.println("Press 1  : to add company manager");
					System.out.println("press 2  : to remove companymanger");
					System.out.println("press 3  : to update company manger");
					System.out.println("press 4  : to add company");
					System.out.println("press 5  : to update company");
					System.out.println("press 6  : to remove company");
					System.out.println("press 7  : to see all investors");
					System.out.println("press 8  : to see all stocks");
					System.out.println("press 9  : to see all company mangers");
					System.out.println("press 10 : to see all companies ");
					System.out.println("Press 11 : to signout from current page");
					System.out.println("<<<<<<---------------------------------->>>>>>");

					int choice = scanner.nextInt();
					switch(choice) {

					case 1 :
						System.out.println("Enter ID :");
						regId = scanner.nextInt();
						System.out.println("Enter Name :");
						regName = scanner.next();
                        System.out.println("Enter Mobile :");
						regMobile = scanner.nextLong();
                        System.out.println("Enter Email :");
						regEmail = scanner.next();
						System.out.println("Enter Password :");
						regPassword = scanner.next();
						System.out.println("Enter Role:");
						regRole = scanner.next();
						
						

						CompanyManagerBean mangerBean = new CompanyManagerBean();
						mangerBean.setId(regId);
						mangerBean.setName(regName);
						mangerBean.setPhoneNumber(regMobile);
						mangerBean.setMailId(regEmail);
						mangerBean.setPassword(regPassword);
						mangerBean.setRole(regRole);

						boolean check = service.registerCompanyManger(mangerBean);
						if(check) {
							System.out.println("Manager Registered succefully");
							System.out.println("<<<<------------------------------>>>>");
							System.out.println("credentials to login manager");
							System.out.println(mangerBean.getMailId());
							System.out.println(mangerBean.getPassword());
						} else {
							System.out.println("Email already exist,please login!!");
						}	

						break;
                   case 2 :
                	   System.out.println("Enter the  manager_Id to remove :");
                	   regId = scanner.nextInt();
                	   if (regId  == 0) {
                		   System.out.println("Enter the Valid manager_Id :");
                	   } else {
                		   CompanyManagerBean managerBean = new CompanyManagerBean();
                		   managerBean.setId(regId );
                		   boolean remove = service.removeManager(regId );
                		   if (remove) {
                			   System.err.println("company manager removed succesfully");
                		   } else {
                			   System.err.println("company manager is not available");
                		   }
                	   }

                	   break;   

                  case 3 :
                	  System.out.println("Enter Id :");
                	  regId = scanner.nextInt();
                	  System.out.println("Enter new Email :");
                	  regEmail = scanner.next();
                	  if (regId == 0) {
                		  System.out.println("Enter the Valid phnumber");
                	  } else {
                		  CompanyManagerBean managerBean = new CompanyManagerBean();
                		  managerBean.setId(regId);
                		  managerBean.setMailId(regEmail);
                		  boolean update = service.updateManager(regEmail, regId);
                		  if (update) {
                			  System.out.println("company manager updated succesfully");
                		  } else {
                			  System.err.println("company manager is not updated");
                		  }
                	  }

                         break;
                    case 4 :
                    	System.out.println("Enter company name :");
                    	companyName = scanner.next();
                    	System.out.println("Enter company id :");
                    	companyId = scanner.nextInt();
                    	CompanyBean bean = new CompanyBean();
                    	bean.setCompName(companyName);
                    	bean.setCompanyId(companyId);
                    	boolean check2 = service.addCompany(bean);
                    	if(check2) {
                    		System.out.println("company added succefully");
                    		System.out.println(String.format("%-5s %-5%",bean.getCompName(),bean.getCompanyId()));
                    	} else {
                    		System.out.println("company  already exist");
                    	}
                         break;
                     case 5:
						System.out.println("enter  company_Id");
						int cId=scanner.nextInt();
						System.out.println("Enter the  new company_name :");
						String cName = scanner.next();
                        if (cId == 0) {
							System.out.println("Enter the Valid company_Id");
						} else {
							CompanyBean companyBean = new CompanyBean();
							companyBean.setCompanyId(cId);
							companyBean.setCompName(cName);
							boolean update = service.updateCompany(cName,cId);
							if (update) {
								System.out.println("company updated succesfully");
							} else {
								System.err.println("company is not availble to update");
							}
						}
                        break;
                     case 6 :
                    	 System.out.println("Enter company name :");
                    	 companyName = scanner.next();
                    	 if (companyName == null) {
                    		 System.out.println("Enter the Valid company_name");
                    	 } else {
                    		 CompanyBean companyBean = new CompanyBean();
                    		 companyBean.setCompName(companyName);
                    		 boolean remove = service.removeCompany(companyName);
                    		 if (remove) {
                    			 System.err.println("company removed succesfully");
                    		 } else {
                    			 System.err.println("company is not available");
                    		 }
                    	 }
                      break;
                    case 7 :
                    	List<UserBean> info1 = service.showUsers();
                    	System.out.println(String.format("%-5s %-20s %-20s %-20s %s", "Id",
                    			"Name","number", "mail", "password"));
                    	for (UserBean userBean : info1) {
                    		if (userBean != null) {
                    			System.out.println(String.format("%-5s %-20s %-20s %-20s %s", userBean.getId(),
                    					userBean.getName(),userBean.getPhoneNumber(), userBean.getMailId(),userBean.getPassword()));
                    		} else {
                    			System.out.println("no users are available");
                    		}
                    	}

                    	break;

					case 8 :
						List<StockBean> info = service.getAllStcokInfo();
						System.out.println(String.format("%-5s %-20s %-20s %-20s %s", "stock-Id",
								"company", "cost", "no of products","type of stock"));
						for (StockBean stockBean : info) {
							if (stockBean != null) {
								System.out.println(String.format("%-5s %-20s %-20s %-20s %s", stockBean.getId(),
										stockBean.getCompanyName(), stockBean.getCost(), stockBean.getNoOfProducts(), stockBean.getTypeOfStock()));

							} else {
								System.out.println("stock info is not present");
							}
						}

						break;

					case 9  :
						List<CompanyManagerBean> info2 = service.getAllCompanyManagerInfo();
						System.out.println(String.format("%-5s %-20s %-20s %-20s %s", "Id",
								"Name","number", "mail", "password"));
						for (CompanyManagerBean managerBean : info2) {
							if (managerBean != null) {
								System.out.println(String.format("%-5s %-20s %-20s %-20s %s", managerBean.getId(),
										managerBean.getName(),managerBean.getPhoneNumber(), managerBean.getMailId(),managerBean.getPassword()));

							} else {
								System.out.println("no managers are available");
							}
						}

						break;
                    case 10 :		
                    	List<CompanyBean> info3 = service.getAllCompanies();
                    	System.out.println(String.format("%-5s %-20s", "company-Id","company_name"));
                    	for (CompanyBean companyBean : info3) {

                    		if (companyBean != null) {
                    			System.out.println(String.format("%-5s %-20s", companyBean.getCompanyId(),
                    					companyBean.getCompName()));

                    		} else {
                    			System.out.println("company info is not present");
                    		}
                    	}
                           break;
					case 11 :
						MainController.mainController();

						break;
					default : 
						System.err.println("plese enter valid choice between 1-11");
					}

				}catch(InputMismatchException e) {
					System.err.println("please enter numeric choice only!!");
                     scanner.next();					
//					adminController();
				}catch (StockException e) {
					System.err.println(e.getMessage());
				}
			}while(true);		
		}else {
			System.err.println("invalid credentials,login first!!!");
		}
		}catch(StockException e ) {

			System.err.println(e.getMessage());
		}

	}

}
