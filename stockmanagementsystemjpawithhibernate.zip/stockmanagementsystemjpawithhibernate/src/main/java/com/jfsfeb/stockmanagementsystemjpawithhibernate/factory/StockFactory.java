package com.jfsfeb.stockmanagementsystemjpawithhibernate.factory;

import com.jfsfeb.stockmanagementsystemjpawithhibernate.dao.AdminDao;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dao.AdminDaoImpl;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dao.CompanyManagerDao;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dao.CompanyManagerDaoImpl;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dao.UserDao;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dao.UserDaoImpl;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.services.AdminService;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.services.AdminServiceImpl;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.services.CompanyManagerService;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.services.CompanyManagerServiceImpl;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.services.UserService;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.services.UserServiceImpl;
import com.jfsfeb.stockmanagementsystemwjpawithhibernate.validations.InputValidation;
import com.jfsfeb.stockmanagementsystemwjpawithhibernate.validations.InputValidationsImpl;

public class StockFactory {
	public static AdminDao getInstanceOfAdminDao() {
		return new AdminDaoImpl();
	}
	
	public static CompanyManagerDao getInstanceOfComapnyMangerDao() {
		return new CompanyManagerDaoImpl();
	}
	
	public static UserDao getInstanceOfUserDao() {
		return new UserDaoImpl();
	}
	public static AdminService getInstanceOfAdminService() {
		return new AdminServiceImpl();
	}
	
	public static UserService getInstanceOfUserService() {
		return new UserServiceImpl();
	}
	
	public static  CompanyManagerService getInstanceOfCompanyMangerService() {
		return new CompanyManagerServiceImpl();
	}
	
	public static  InputValidation getInstanceOfInvaInputValidation() {
		return new InputValidationsImpl();
	}
   

}
