package com.jfsfeb.stockmanagementsystemjpawithhibernate.dto;

import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="companytable")
public class CompanyBean {
     @Id
     @Column
	 private int companyId;
     @Column
	 private String compName;
	
}
