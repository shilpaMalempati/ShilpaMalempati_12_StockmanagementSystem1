package com.jfsfeb.stockmanagementsystemjpawithhibernate.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="usertable")
public class CompanyManagerBean {
	@Id
	@Column
	 private int id;
	@Column
	 private String name;
	@Column
	 private long phoneNumber;
	@Column
	 private String mailId;
	@Column
	 private String password;
	@Column
	 private String role;

	}
