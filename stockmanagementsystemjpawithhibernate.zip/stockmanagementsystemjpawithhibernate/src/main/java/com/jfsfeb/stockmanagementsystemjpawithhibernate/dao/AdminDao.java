package com.jfsfeb.stockmanagementsystemjpawithhibernate.dao;

import java.util.List;

import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.AdminBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.CompanyBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.CompanyManagerBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.StockBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.UserBean;

public interface AdminDao {
	boolean registerCompanyManger(CompanyManagerBean managerBean);
	AdminBean adminLogin(String email,String password);
	boolean removeManager(int id);
	boolean updateManager(String mail, int id);
	boolean addCompany(CompanyBean companyBean);
	boolean updateCompany(String comName,int id);
	boolean removeCompany(String compName);
	
	List<UserBean> showUsers();
	List<CompanyBean> getAllCompanies();
	List<StockBean> getAllStcokInfo();
	List<CompanyManagerBean> getAllCompanyManagerInfo();
	
	
	
}
