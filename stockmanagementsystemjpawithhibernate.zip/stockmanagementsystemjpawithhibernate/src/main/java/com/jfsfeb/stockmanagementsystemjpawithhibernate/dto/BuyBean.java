package com.jfsfeb.stockmanagementsystemjpawithhibernate.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="buybeantable")
public class BuyBean {
	@Id
	@Column
	int stockId;
	@Column
	String CompanyName;
	@Column
	int noOfProducts;
	@Column
	double cost;
	@Column
	String stockType;
	@Column
	int userId;
	@Column
	String userName;

}
