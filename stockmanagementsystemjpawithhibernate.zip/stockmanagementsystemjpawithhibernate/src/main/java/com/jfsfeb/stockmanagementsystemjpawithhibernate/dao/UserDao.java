package com.jfsfeb.stockmanagementsystemjpawithhibernate.dao;

import java.util.List;

import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.BuyBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.BuyStockBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.StockBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.UserBean;


public interface UserDao {
	boolean registerUser(UserBean user);
	UserBean loginUser(String email,String password);
	BuyBean buyStock(UserBean user, StockBean stockBean, BuyBean buyBean);
	List<StockBean> searchProductByType(String type);
	List<StockBean> searchProductByName(String name);
	List<StockBean> getAllStcokInfo();
	boolean changePassword(long mobile, String password);
	boolean updateProfile(String mail, long phNum);
	List<BuyBean> getAllBuyStockInfo();


}
