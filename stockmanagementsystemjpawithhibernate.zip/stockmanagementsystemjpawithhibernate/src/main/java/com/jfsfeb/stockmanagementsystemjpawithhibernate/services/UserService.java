package com.jfsfeb.stockmanagementsystemjpawithhibernate.services;

import java.util.List;

import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.BuyBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.BuyStockBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.StockBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.UserBean;


public interface UserService {
	boolean registerUser(UserBean user);
	UserBean loginUser(String email,String password);
	public BuyBean buyStock(UserBean user, StockBean stockBean,BuyBean buyBean);
	List<StockBean> searchProductByType(String type);
	List<StockBean> searchProductByName(String name);
	List<StockBean> getAllStcokInfo();
	List<BuyBean> getAllBuyStockInfo();
	boolean changePassword(long mobile, String password);
	boolean updateProfile(String mail, long phNum);


}
