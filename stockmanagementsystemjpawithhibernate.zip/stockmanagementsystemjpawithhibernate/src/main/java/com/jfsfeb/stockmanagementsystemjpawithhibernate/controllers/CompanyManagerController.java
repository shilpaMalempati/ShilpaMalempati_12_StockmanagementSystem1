package com.jfsfeb.stockmanagementsystemjpawithhibernate.controllers;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import com.jfsfeb.stockmanagementsystemjpawithhibernate.dao.AdminDao;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.AdminBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.CompanyManagerBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.StockBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.exceptions.StockException;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.factory.StockFactory;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.services.CompanyManagerService;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.services.CompanyManagerServiceImpl;
import com.jfsfeb.stockmanagementsystemwjpawithhibernate.validations.InputValidationsImpl;

@SuppressWarnings("unused")
public class CompanyManagerController {
   public void companyManagerController() {
		
		
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
      
		int regId = 0; 
		String regName = null; 
		long regMobile = 0;
		String regEmail = null;
		String regPassword = null;

        int stockId = 0; 
		String stockCName = null;
		String stockType = null;
		int stcokNoOfProducts=0;
		double stockCost = 0.0;

		String loginMail=null;
		String loginPassword=null;

        CompanyManagerService service2 = StockFactory.getInstanceOfCompanyMangerService();
        System.out.println("<<<<<<>>>>>----------welcome to company manger blog,plsease login---------<<<<<>>>>>");
		System.out.println("Enter Email :");
		loginMail = scanner.next();
		System.out.println("Enter Password :");
		loginPassword = scanner.next();
		System.out.println();
		
		try {
			CompanyManagerBean login = service2.managerLogin(loginMail,loginPassword);
			if(login!=null) {
			System.out.println("You have logged in successfully");
			String s= new String(login.getName());
			System.out.println("<<<<>>>>------------WELCOME "+s.toUpperCase()+"---------<<<<>>>>");
			System.out.println();
			System.out.println("Now you can perform the following operations:-");
			System.out.println();
			do{
				try {
					System.out.println("<<<<<--------------------------------->>>>>");
					System.out.println("Press 1  : to change password");
					System.out.println("press 2  : to add stock");
					System.out.println("press 3  : to update the type of stock");
					System.out.println("press 4  : to update the cost of stock");
					System.out.println("press 5  : to update the no of stock ");
					System.out.println("press 6  : to remove stock");
					System.out.println("press 7  : to search stock by stock type");
					System.out.println("press 8  : to search stock by company name");
					System.out.println("press 9  : to read the all stock");
					System.out.println("press 10 : to logout from this current blog");
					System.out.println("<<<<<------------------------------------>>>>");

					int choice = scanner.nextInt();
					switch(choice) {

					case 1 :
						System.out.println("Enter Mobile :");
						regMobile  = scanner.nextLong();
						System.out.println("Enter new Password :");
						regPassword = scanner.next();
						
						if (regMobile == 0) {
							System.out.println("Enter the Valid phnumber");
						} else {

							Random random = new Random();
							int otp = random.nextInt(9999);
							System.out.println(otp<0?otp*-1:otp);

							System.out.println("please ,enter otp.... ");
							int typeOtp = scanner.nextInt();
							if(otp==typeOtp) {

								CompanyManagerBean bean = new CompanyManagerBean();
								bean.setPhoneNumber(regMobile);
								bean.setPassword(regPassword);
								boolean update = service2.changePassword(regMobile,regPassword);
								if (update) {
									System.out.println("password updated succesfully");
								} else {
									System.err.println("passwrod is not updated");
								}
							}else {
								System.err.println("otp mismatched,please try again!!");
							}
						}


						break;


					case 2 :
						try {
						System.out.println("Enter stock-ID :");
						stockId = scanner.nextInt();
						System.out.println("Enter company Name :");
						stockCName = scanner.next();
						System.out.println("Enter stock name :");
						stockType = scanner.next();
                        System.out.println("enter cost of product");
						stockCost= scanner.nextDouble();
                        System.out.println("enter no of products");
						stcokNoOfProducts = scanner.nextInt();
						
						StockBean bean1 = new StockBean();
						bean1.setId(stockId);	
						bean1.setCompanyName(stockCName);
						bean1.setCost(stockCost);
						bean1.setTypeOfStock(stockType);
						bean1.setNoOfProducts(stcokNoOfProducts);
						boolean check2 = service2.addStock(bean1);
						if(check2) {
							System.out.println("stock Added succefully");
							System.out.println(String.format("%-5s %-20s %-20s %-20s %s",bean1.getId(),bean1.getCompanyName(),bean1.getCost(),
									bean1.getTypeOfStock(),bean1.getNoOfProducts()));
						} else {
							System.out.println("stock already exist");
						}
						}catch (InputMismatchException e) {
							System.err.println("please enter stock name with alphabets and id with didgits");
							scanner.next();
						}

						break;

					case 3 :
						System.out.println("enter  Stock_Id");
						int sId=scanner.nextInt();
						System.out.println("Enter the new stock_type :");
						String sType = scanner.next();
                        if (sId == 0) {
							System.out.println("Enter the Valid stock_id");
						} else {
							StockBean bean6 = new StockBean();
							bean6.setId(sId);
							bean6.setTypeOfStock(sType);
							boolean update = service2.updateStockTypeById(sId, sType);
							if (update) {
								System.out.println("stock updated succesfully");
							} else {
								System.err.println("stock-id is not available");
							}
						}

						break;
					case 4 :
						System.out.println("enter  Stock_Id");
						 stockId=scanner.nextInt();
						System.out.println("Enter the new stock_Cost :");
						 stockCost = scanner.nextDouble();
                        if (stockId==0) {
							System.out.println("Enter the Valid stock_Name");
						} else {
							StockBean bean6 = new StockBean();
							bean6.setCost(stockCost);
							bean6.setId(stockId);
							boolean update = service2.updateStockCostById(stockId, stockCost);
							if (update) {
								System.out.println("stock updated succesfully");
							} else {
								System.err.println("stock is not available");
							}
						}
                          break;

					case 5 :
						System.out.println("enter Stock_Id");
						stockId =scanner.nextInt();
						System.out.println("Enter the  no of stock:");
						int count = scanner.nextInt();


						if (stockId == 0) {
							System.out.println("Enter the Valid stock_type");
						} else {
							StockBean bean6 = new StockBean();
							bean6.setId(stockId );
							bean6.setNoOfProducts(count);
							boolean update = service2.updateStockCountById(stockId , count);
							if (update) {
								System.out.println("stock updated succesfully");
							} else {
								System.err.println("stock is not available");
							}
						}

						break;

					case 6 :
						System.out.println("Enter the stock_Id to delete :");
						int stockId1 = scanner.nextInt();
						if (stockId1 == 0) {
							System.out.println("Enter the Valid stock_Id");
						} else {
							StockBean bean6 = new StockBean();
							bean6.setId(stockId1);
							boolean remove = service2.removeStock(stockId1);
							if (remove) {
								System.err.println("The stock is removed succefully");
							} else {
								System.err.println("The stock is not availble with this id !!");
							}
						}
						break;

					case 7 :

						System.out.println("  enter the stock type :");
						String stockType1 = scanner.next();
						StockBean bean3 = new StockBean();
						List<StockBean> stockType2 = service2.searchProductByType(stockType1);
						
						if(stockType2!=null) {
							System.out.println(String.format("%-5s %-20s %-20s %-20s %s", "stock-Id",
									"company", "cost", "no of products","type of stock"));
							for (StockBean stockBean : stockType2) {	
								if (stockBean != null) {
									System.out.println(String.format("%-5s %-20s %-20s %-20s %s",  stockBean.getId(),
											stockBean.getCompanyName(), stockBean.getCost(), stockBean.getNoOfProducts(), stockBean.getTypeOfStock()));
								} 
							}
						}else {
							System.err.println("No stocks are available with this type.");
						}

						break;


					case 8 :

						System.out.println("enter the company Name:");
						String comName = scanner.next();

						List<StockBean> company = service2.searchProductByName(comName);
						if(company!=null) {
							System.out.println(String.format("%-5s %-20s %-20s %-20s %s", "stock-Id",
									"company", "cost", "no of products","type of stock"));
							for (StockBean stockBean : company) {

								if (stockBean != null) {

									System.out.println(String.format("%-5s %-20s %-20s %-20s %s", stockBean.getId(),
											stockBean.getCompanyName(), stockBean.getCost(), stockBean.getNoOfProducts(), stockBean.getTypeOfStock()));

								} 
							}
						}else {
							System.err.println("No stocks are available with this companyname");
						}

						break;

					case 9 :
						List<StockBean> info = service2.getAllStcokInfo();
						System.out.println(String.format("%-5s %-20s %-20s %-20s %s", "stock-Id",
								"company", "cost", "no of products","type of stock"));
						for (StockBean stockBean : info) {

							if (stockBean != null) {
								System.out.println(String.format("%-5s %-20s %-20s %-20s %s", stockBean.getId(),
										stockBean.getCompanyName(), stockBean.getCost(), stockBean.getNoOfProducts(), stockBean.getTypeOfStock()));

							} else {
								System.out.println("stock info is not present");
							}
						}
						break;

                    case 10 :
						MainController.mainController();
						break;
					default:
						System.err.println("please enter valid positive choice between 1-10");

					}

				}catch(StockException e) {
					System.err.println(e.getMessage());
					companyManagerController();
				}catch(InputMismatchException e) {
				       System.err.println("enter valid numeric choice onlyy");
				       companyManagerController();
				}
			}while(true);
			}else {
				System.out.println("invalid credentials,try to login again!!");
			}
		}catch(StockException e) {
			System.err.println(e.getMessage());
		}


	}

}
