package com.jfsfeb.stockmanagementsystemjpawithhibernate.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.BuyBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.BuyStockBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.CompanyManagerBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.StockBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.UserBean;

public class UserDaoImpl implements UserDao  {
	
	public boolean registerUser(UserBean user) {
	   UserBean bean = new UserBean();
		bean.setId(user.getId());
		bean.setName(user.getName());
		bean.setPhoneNumber(user.getPhoneNumber());
		bean.setMailId(user.getMailId());
		bean.setPassword(user.getPassword());
		bean.setRole(user.getRole());
		
		EntityManagerFactory entityManagerFactory= null;
		EntityManager entityManager= null;
		EntityTransaction entityTransaction= null;
		try {
			entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
			entityManager = entityManagerFactory.createEntityManager();
			entityTransaction = entityManager.getTransaction();
			entityTransaction.begin();
			entityManager.persist(bean);
			entityTransaction.commit();
			System.out.println("record saved");
				return true;

		}catch(Exception e) {
			entityTransaction.rollback();
		} 
		
		entityManager.close();
		entityManagerFactory.close();
		return false;	

				}


	public UserBean loginUser(String email, String password){
		EntityManagerFactory entityManagerFactory= null;
		EntityManager entityManager= null;
		EntityTransaction entityTransaction= null;

		try {
		entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
		entityManager = entityManagerFactory.createEntityManager();
		String jpql="select u from UserBean u where u.mailId=:email and u.password=:password and u.role='investors'";
		TypedQuery<UserBean> query = entityManager.createQuery(jpql,UserBean.class);
		query.setParameter("email", email);
		query.setParameter("password", password);
		UserBean bean = query.getSingleResult();
		return bean;
	  }catch(NullPointerException e){
		System.err.println(e.getMessage());
		return null;
	  }finally {
		entityManager.close();
		entityManagerFactory.close();
	  }
	}

	public List<StockBean> searchProductByName(String name) {
		EntityManagerFactory entityManagerFactory= null;
		EntityManager entityManager= null;
		EntityTransaction entityTransaction= null;

		try {
			entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
			entityManager = entityManagerFactory.createEntityManager();
			String jpql = "select s from StockBean s where s.companyName=:comName";
			TypedQuery<StockBean> query = entityManager.createQuery(jpql,StockBean.class);
			query.setParameter("comName", name);
			List<StockBean> recordList = query.getResultList();
			return recordList; 
		}catch (Exception e) {
			System.err.println(e.getMessage());
			return null;
		}finally {
			entityManager.close();
			entityManagerFactory.close();
		}
	}


	public List<StockBean> searchProductByType(String type) {
		EntityManagerFactory entityManagerFactory= null;
		EntityManager entityManager= null;
		EntityTransaction entityTransaction= null;

		try {
			entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
			entityManager = entityManagerFactory.createEntityManager();
			String jpql = "select s from StockBean s where s.typeOfStock=:type";
			TypedQuery<StockBean> query = entityManager.createQuery(jpql,StockBean.class);
			query.setParameter("type", type);
			List<StockBean> recordList = query.getResultList();
			return recordList; 
		}catch (Exception e) {
			System.err.println(e.getMessage());
			return null;
		}finally {
			entityManager.close();
			entityManagerFactory.close();
		}
	 }

	public List<StockBean> getAllStcokInfo() {
        StockBean bean= new StockBean();
		EntityManagerFactory entityManagerfactory = Persistence.createEntityManagerFactory("TestPersistence");
		EntityManager manager = entityManagerfactory.createEntityManager(); 
		String jpql = "select s from StockBean s ";
		
		Query query = manager.createQuery(jpql);
		List<StockBean> recordList = query.getResultList();
		if(recordList!=null) {
			for(StockBean objects : recordList ) {

				bean.setId(objects.getId());
				bean.setCompanyName(objects.getCompanyName());
				bean.setNoOfProducts(objects.getNoOfProducts());
				bean.setCost(objects.getCost());
				bean.setTypeOfStock(objects.getTypeOfStock());
			    recordList.add(bean);
                return recordList;
			}
		}
		manager.close();
		entityManagerfactory.close();
		return null;
	}


	public BuyBean buyStock(UserBean user, StockBean stockBean,BuyBean buyBean) {
		EntityManagerFactory entityManagerFactory= null;
		EntityManager entityManager= null;
		EntityTransaction entityTransaction= null;
      	buyBean= new BuyBean();
		
		try {
			entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
			entityManager = entityManagerFactory.createEntityManager();
			entityTransaction = entityManager.getTransaction();
			entityTransaction.begin();
			
			UserBean userBean= entityManager.find(UserBean.class, user.getId());
			StockBean stockBean1= entityManager.find(StockBean.class,stockBean.getId());
              
			if(userBean!=null && stockBean1!=null) {
				if(stockBean1.getNoOfProducts()>= buyBean.getNoOfProducts() && stockBean1.getCost() >= buyBean.getCost()) {
				 buyBean.setCompanyName(stockBean1.getCompanyName());
				 buyBean.setCost(buyBean.getCost());
				 buyBean.setNoOfProducts(buyBean.getNoOfProducts());
				 buyBean.setStockType(stockBean1.getTypeOfStock());
				 buyBean.setUserId(userBean.getId());
				 buyBean.setUserName(userBean.getName());
	             buyBean.setStockId(stockBean1.getId());
	             entityManager.persist(buyBean);
                 entityTransaction.commit();
                 System.out.println("record saved");
			
                  return buyBean;
				}else {
					System.out.println("no of products and costs are overloaded");
				}
	      }else {
	    	  return null;
	      }
		}
		catch(Exception e) {
			entityTransaction.rollback();
		}
		entityManager.close();
		entityManagerFactory.close();
		return null;
     }


	@Override
	public boolean changePassword(long mobile, String password) {
		EntityManagerFactory entityManagerFactory = null;
		EntityManager manager = null;
		EntityTransaction transaction = null;
		try {
		 entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
		 manager = entityManagerFactory.createEntityManager();
		 transaction = manager.getTransaction();
		 transaction.begin();
		String jpql = "update UserBean u set u.password=:password  where u.phoneNumber=:phoneNumber ";
		Query query = manager.createQuery(jpql);
		query.setParameter("password",password);
		query.setParameter("phoneNumber", mobile);
		int record = query.executeUpdate();
		System.out.println("Record Update --" +record);
		transaction.commit();
		return true;
		} catch(Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}
		manager.close();
		entityManagerFactory.close();
		return false;
		}


	@Override
	public boolean updateProfile(String mail, long phNum) {
		EntityManagerFactory entityManagerFactory= null;
		EntityManager entityManager= null;
		EntityTransaction entityTransaction= null;

		try {
		entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
		entityManager = entityManagerFactory.createEntityManager();
		String jpql="update UserBean u set u.mailId=:mail  where u.phoneNumber=:phoneNumber and role='investors'";
		TypedQuery<UserBean> query = entityManager.createQuery(jpql,UserBean.class);
		query.setParameter("mail", mail);
		query.setParameter("phoneNumber", phNum);
		UserBean bean = query.getSingleResult();
		return true;
	  }catch(Exception e){
		System.err.println(e.getMessage());
		return false;
	  }finally {
		entityManager.close();
		entityManagerFactory.close();
	  }
	}

    @Override
	public List<BuyBean> getAllBuyStockInfo() {
    	BuyBean bean= new BuyBean();
		EntityManagerFactory entityManagerfactory = Persistence.createEntityManagerFactory("TestPersistence");
		EntityManager manager = entityManagerfactory.createEntityManager(); 
		String jpql = "select b from BuyBean b ";
		
		Query query = manager.createQuery(jpql);
		List<BuyBean> recordList = query.getResultList();
		if(recordList!=null) {
			for(BuyBean objects : recordList ) {

				bean.setStockId(objects.getStockId());
				bean.setCompanyName(objects.getCompanyName());
				bean.setNoOfProducts(objects.getNoOfProducts());
				bean.setCost(objects.getCost());
				bean.setStockType(objects.getStockType());
				bean.setUserId(objects.getUserId());
				bean.setUserName(objects.getUserName());
			    recordList.add(bean);
                return recordList;
			}
			
		}
		manager.close();
		entityManagerfactory.close();
		return null;
    	}
 }


