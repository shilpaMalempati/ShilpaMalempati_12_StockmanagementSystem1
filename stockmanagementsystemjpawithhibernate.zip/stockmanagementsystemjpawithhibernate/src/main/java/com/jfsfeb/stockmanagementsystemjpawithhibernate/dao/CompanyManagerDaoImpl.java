package com.jfsfeb.stockmanagementsystemjpawithhibernate.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.AdminBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.CompanyManagerBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.StockBean;



public class CompanyManagerDaoImpl implements CompanyManagerDao {

	@Override
	public CompanyManagerBean managerLogin(String email, String password) {
		EntityManagerFactory entityManagerFactory= null;
		EntityManager entityManager= null;
		EntityTransaction entityTransaction= null;

		try {
		entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
		entityManager = entityManagerFactory.createEntityManager();
		String jpql="select c from CompanyManagerBean c where c.mailId=:email and c.password=:password and c.role='companyManager'";
		TypedQuery<CompanyManagerBean> query = entityManager.createQuery(jpql,CompanyManagerBean.class);
		query.setParameter("email", email);
		query.setParameter("password", password);
		CompanyManagerBean bean = query.getSingleResult();
		 return bean;
	  }catch(NullPointerException e){
		System.err.println(e.getMessage());
//		return null;
	  }
		entityManager.close();
		entityManagerFactory.close();
		return null;
	  
	}

	@Override
	public boolean changePassword(long mobile, String password) {
		
		EntityManagerFactory entityManagerFactory = null;
		EntityManager manager = null;
		EntityTransaction transaction = null;
		try {
		 entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
		 manager = entityManagerFactory.createEntityManager();
		 transaction = manager.getTransaction();
		 transaction.begin();
		String jpql = "update CompanyManagerBean c set c.password=:password  where c.phoneNumber=:phoneNumber ";
		Query query = manager.createQuery(jpql);
		query.setParameter("password",password);
		query.setParameter("phoneNumber", mobile);
		int record = query.executeUpdate();
		System.out.println("Record Update --" +record);
		transaction.commit();
		return true;
		} catch(Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}
		manager.close();
		entityManagerFactory.close();
		return false;
	}


	@Override
	public boolean addStock(StockBean stockBean) {
		
	    StockBean bean = new StockBean();
		bean.setId(stockBean.getId());
		bean.setCompanyName(stockBean.getCompanyName());
		bean.setNoOfProducts(stockBean.getNoOfProducts());
		bean.setCost(stockBean.getCost());
		bean.setTypeOfStock(stockBean.getTypeOfStock());
		
		EntityManagerFactory entityManagerFactory= null;
		EntityManager entityManager= null;
		EntityTransaction entityTransaction= null;
		try {
			entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
			entityManager = entityManagerFactory.createEntityManager();
			entityTransaction = entityManager.getTransaction();
			entityTransaction.begin();
			
				entityManager.persist(bean);
				entityTransaction.commit();
				System.out.println("record saved");
				return true;

		}catch(Exception e) {
			entityTransaction.rollback();
		} 
		
		entityManager.close();
		entityManagerFactory.close();
		return false;	
     }

	@Override
	public boolean updateStockTypeById(int id, String type) {
		EntityManagerFactory entityManagerFactory= null;
		EntityManager entityManager= null;
		EntityTransaction entityTransaction= null;
		try {
		 entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
		entityManager = entityManagerFactory.createEntityManager();
		entityTransaction = entityManager.getTransaction();
		entityTransaction.begin();
	    StockBean update =entityManager.find(StockBean.class,id);
		update.setTypeOfStock(type);
		System.out.println("record updated");
		entityTransaction.commit();
		return true;
		
		}
	   catch(Exception e) {
		entityTransaction.rollback();
	   }
		entityManager.clear();
		entityManagerFactory.close();
		return false;
		}

	@Override
	public boolean updateStockCostById(int id, double cost) {
		EntityManagerFactory entityManagerFactory= null;
		EntityManager entityManager= null;
		EntityTransaction entityTransaction= null;
		try {
		 entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
		entityManager = entityManagerFactory.createEntityManager();
		entityTransaction = entityManager.getTransaction();
		entityTransaction.begin();
	    StockBean update =entityManager.find(StockBean.class,id);
		update.setCost(cost);
		System.out.println("record updated");
		entityTransaction.commit();
		return true;
		
		}
	   catch(Exception e) {
		entityTransaction.rollback();
	   }
		entityManager.clear();
		entityManagerFactory.close();

		return false;
				
	}

	@Override
	public boolean updateStockCountById(int id, int count) {
		EntityManagerFactory entityManagerFactory= null;
		EntityManager entityManager= null;
		EntityTransaction entityTransaction= null;
		try {
		 entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
		entityManager = entityManagerFactory.createEntityManager();
		entityTransaction = entityManager.getTransaction();
		entityTransaction.begin();
	    StockBean update =entityManager.find(StockBean.class,id);
		update.setNoOfProducts(count);
		System.out.println("record updated");
		entityTransaction.commit();
		return true;
		
		}
	   catch(Exception e) {
		entityTransaction.rollback();
	   }
		entityManager.clear();
		entityManagerFactory.close();
		return false;
				}

	@Override
	public boolean removeStock(int id) {
		EntityManagerFactory entityManagerFactory= null;
		EntityManager entityManager= null;
		EntityTransaction entityTransaction= null;

		try {
			entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
			entityManager = entityManagerFactory.createEntityManager();
		    entityTransaction = entityManager.getTransaction();
			entityTransaction.begin();

			StockBean bean =entityManager.find(StockBean.class, id);
			int testId=bean.getId();
			if(testId!=0) {
				entityManager.remove(bean);
				System.out.println("deleted succefully");
				entityTransaction.commit();
				return true;
			}
		  }catch(Exception e) {
	          e.printStackTrace(); 
	     }
			
			entityManager.close();
			entityManagerFactory.close();
			return false;
       }

	@Override
	public List<StockBean> searchProductByName(String name) {
		EntityManagerFactory entityManagerFactory= null;
		EntityManager entityManager= null;
		EntityTransaction entityTransaction= null;

		try {
			entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
			entityManager = entityManagerFactory.createEntityManager();
			String jpql = "select s from StockBean s where s.companyName=:comName";
			TypedQuery<StockBean> query = entityManager.createQuery(jpql,StockBean.class);
			query.setParameter("comName", name);
			List<StockBean> recordList = query.getResultList();
			return recordList; 
		}catch (Exception e) {
			System.err.println(e.getMessage());
			return null;
		}finally {
			entityManager.close();
			entityManagerFactory.close();
		}

      }

	@Override
	public List<StockBean> searchProductByType(String type) {
		EntityManagerFactory entityManagerFactory= null;
		EntityManager entityManager= null;
		EntityTransaction entityTransaction= null;

		try {
			entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
			entityManager = entityManagerFactory.createEntityManager();
			String jpql = "select s from StockBean s where s.typeOfStock=:type";
			TypedQuery<StockBean> query = entityManager.createQuery(jpql,StockBean.class);
			query.setParameter("type", type);
			List<StockBean> recordList = query.getResultList();
			return recordList; 
		}catch (Exception e) {
			System.err.println(e.getMessage());
			return null;
		}finally {
			entityManager.close();
			entityManagerFactory.close();
		}
	 }

	@Override
	public List<StockBean> getAllStcokInfo() {
		StockBean bean= new StockBean();
		EntityManagerFactory entityManagerfactory = Persistence.createEntityManagerFactory("TestPersistence");
		EntityManager manager = entityManagerfactory.createEntityManager(); 
		String jpql = "select s from StockBean s ";
		
		Query query = manager.createQuery(jpql);
		List<StockBean> recordList = query.getResultList();
		if(recordList!=null) {
			for(StockBean objects : recordList ) {

				bean.setId(objects.getId());
				bean.setCompanyName(objects.getCompanyName());
				bean.setNoOfProducts(objects.getNoOfProducts());
				bean.setCost(objects.getCost());
				bean.setTypeOfStock(objects.getTypeOfStock());
			    recordList.add(bean);
                return recordList;
			}
			
		}
		manager.close();
		entityManagerfactory.close();
		return null;
	}
}
