package com.jfsfeb.stockmanagementsystemjpawithhibernate.services;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import org.omg.CORBA.CTX_RESTRICT_SCOPE;

import com.jfsfeb.stockmanagementsystemjpawithhibernate.controllers.AdminController;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dao.AdminDao;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dao.AdminDaoImpl;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.AdminBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.CompanyBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.CompanyManagerBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.StockBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.UserBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.exceptions.StockException;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.factory.StockFactory;
import com.jfsfeb.stockmanagementsystemwjpawithhibernate.validations.InputValidation;
import com.jfsfeb.stockmanagementsystemwjpawithhibernate.validations.InputValidationsImpl;

import lombok.val;

public class AdminServiceImpl implements AdminService{
	
	private AdminDao dao = StockFactory.getInstanceOfAdminDao();
	
	InputValidation validation = StockFactory.getInstanceOfInvaInputValidation();

	@Override
	public boolean registerCompanyManger(CompanyManagerBean managerBean) {
		if(managerBean!=null){
			if(validation.validatedId(managerBean.getId())) {
				if(validation.validatedName(managerBean.getName())) {
					if(validation.validatedMobile(managerBean.getPhoneNumber())) {
						if(validation.validatedEmail(managerBean.getMailId())) {
							if(validation.validatedPassword(managerBean.getPassword())) {
								return dao.registerCompanyManger(managerBean);
							}
						}
					}
				}
			}
		}
		return false;
	}
	@Override
	public AdminBean adminLogin(String email, String password) {
		if(email!=null && password !=null) {
			if (validation.validatedEmail(email)) {
				if (validation.validatedPassword(password)) {
					return dao.adminLogin(email, password);
				}
			}
		}
		return null;
	        
   }

	@Override
	public boolean removeManager(int id) {
		if(id!=0) {
			if(validation.validatedId(id)) {
			         return dao.removeManager(id);
			}
		}
		return false;
	}

	@Override
	public boolean updateManager(String mail, int id) {
       if(mail!=null && id!=0) {
    	   if(validation.validatedEmail(mail)) {
    		   if(validation.validatedId(id)) {
    	               return dao.updateManager(mail, id);
    		   }
    	   }
       }
	       return false;
	}
	
	@Override
	public boolean addCompany(CompanyBean companyBean) {
		if(companyBean !=null) {
			if(validation.validatedId(companyBean.getCompanyId())) {
				if(validation.validatedName(companyBean.getCompName())) {
			                return dao.addCompany(companyBean);
				}
			}
		}
		return false;
		
	}

	@Override
	public boolean removeCompany(String companyName) {
		if(companyName!=null) {
			if(validation.validatedName(companyName)) {
			return dao.removeCompany(companyName);
			}
		}
		return false;
	}

	@Override
	public boolean updateCompany(String comName, int id) {
		if(comName != null && id!=0) {
			if(validation.validatedName(comName)) {
				if(validation.validatedId(id)) {
			          return dao.updateCompany(comName, id);
				}
			}
		}
		return false;
	}

	@Override
	public List<UserBean> showUsers() {
		return dao.showUsers();
	}
	
    @Override
	public List<CompanyBean> getAllCompanies() {
		return dao.getAllCompanies();
	}

	@Override
	public List<StockBean> getAllStcokInfo() {
		return dao.getAllStcokInfo();
	}

	@Override
	public List<CompanyManagerBean> getAllCompanyManagerInfo() {
		 return dao.getAllCompanyManagerInfo();
	}

	
}

