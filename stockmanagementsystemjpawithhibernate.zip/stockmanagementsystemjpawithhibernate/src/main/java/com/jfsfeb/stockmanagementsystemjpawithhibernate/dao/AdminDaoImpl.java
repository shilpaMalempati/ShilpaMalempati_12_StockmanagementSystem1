package com.jfsfeb.stockmanagementsystemjpawithhibernate.dao;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.AdminBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.CompanyBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.CompanyManagerBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.StockBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.UserBean;

public class AdminDaoImpl implements AdminDao{
	
	@Override
	public boolean registerCompanyManger(CompanyManagerBean managerBean) {
				
		CompanyManagerBean bean = new CompanyManagerBean();
		bean.setId(managerBean.getId());
		bean.setName(managerBean.getName());
		bean.setPhoneNumber(managerBean.getPhoneNumber());
		bean.setMailId(managerBean.getMailId());
		bean.setPassword(managerBean.getPassword());
		bean.setRole(managerBean.getRole());
		
		EntityManagerFactory entityManagerFactory= null;
		EntityManager entityManager= null;
		EntityTransaction entityTransaction= null;
		try {
			entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
			entityManager = entityManagerFactory.createEntityManager();
			entityTransaction = entityManager.getTransaction();
			entityTransaction.begin();
			
				entityManager.persist(bean);
				entityTransaction.commit();
				System.out.println("record saved");
				return true;

		}catch(Exception e) {
			entityTransaction.rollback();
		} 
		
		entityManager.close();
		entityManagerFactory.close();
		return false;	
	}

	@Override
	public AdminBean adminLogin(String email, String password) {
		
		EntityManagerFactory entityManagerFactory= null;
		EntityManager entityManager= null;
		EntityTransaction entityTransaction= null;

		try {
		entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
		entityManager = entityManagerFactory.createEntityManager();
		String jpql="select a from AdminBean a where a.mailId=:email and a.password=:password and a.role='admin'";
		TypedQuery<AdminBean> query = entityManager.createQuery(jpql,AdminBean.class);
		query.setParameter("email", email);
		query.setParameter("password", password);
		AdminBean bean = query.getSingleResult();
		return bean;
	  }catch(Exception e){
		System.err.println(e.getMessage());
		return null;
	  }finally {
		entityManager.close();
		entityManagerFactory.close();
	  }

     }

	@Override
	public boolean removeManager(int id) {
		EntityManagerFactory entityManagerFactory= null;
		EntityManager entityManager= null;
		EntityTransaction entityTransaction= null;

		try {
			entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
			entityManager = entityManagerFactory.createEntityManager();
		    entityTransaction = entityManager.getTransaction();
			entityTransaction.begin();

			CompanyManagerBean bean =entityManager.find(CompanyManagerBean.class, id);
			int testId=bean.getId();
			if(testId!=0) {
				entityManager.remove(bean);
				System.out.println("deleted succefully");
				entityTransaction.commit();
				return true;
			}
		  }catch(Exception e) {
	          e.printStackTrace(); 
	     }
			
			entityManager.close();
			entityManagerFactory.close();
			return false;
        }

	@Override
	public boolean updateManager(String mail, int id) {
		EntityManagerFactory entityManagerFactory= null;
		EntityManager entityManager= null;
		EntityTransaction entityTransaction= null;
		try {
		 entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
		entityManager = entityManagerFactory.createEntityManager();
		entityTransaction = entityManager.getTransaction();
		entityTransaction.begin();
	    CompanyManagerBean update =entityManager.find(CompanyManagerBean.class,id);
		update.setMailId(mail);
		System.out.println("record updated");
		entityTransaction.commit();
		return true;
		
		}
	   catch(Exception e) {
		entityTransaction.rollback();
	   }
		entityManager.clear();
		entityManagerFactory.close();
		return false;

	}
	

    @Override
	public boolean updateCompany(String comName, int id) {
    	EntityManagerFactory entityManagerFactory= null;
		EntityManager entityManager= null;
		EntityTransaction entityTransaction= null;
		try {
		 entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
		entityManager = entityManagerFactory.createEntityManager();
		entityTransaction = entityManager.getTransaction();
		entityTransaction.begin();
	    CompanyBean update =entityManager.find(CompanyBean.class,id);
		update.setCompName(comName);
		System.out.println("record updated");
		entityTransaction.commit();
		return true;
		
		}
	   catch(Exception e) {
		entityTransaction.rollback();
	   }
		entityManager.clear();
		entityManagerFactory.close();
		return false;


	}

	@Override
	public List<UserBean> showUsers() {
		UserBean bean= new UserBean();
		EntityManagerFactory entityManagerfactory = Persistence.createEntityManagerFactory("TestPersistence");
		EntityManager manager = entityManagerfactory.createEntityManager(); 
		String jpql = "select u from UserBean u where u.role='investors'";
		
		Query query = manager.createQuery(jpql);
		List<UserBean> recordList = query.getResultList();
		if(recordList!=null) {
			for(UserBean objects : recordList ) {

				bean.setId(objects.getId());
				bean.setName(objects.getName());
				bean.setPhoneNumber(objects.getPhoneNumber());
				bean.setMailId(objects.getMailId());
				bean.setPassword(objects.getPassword());
				bean.setRole(objects.getRole());
                recordList.add(bean);
                return recordList;
			}
			
		}
		manager.close();
		entityManagerfactory.close();
		return null;
		
	}
  
	

	@Override
	public List<CompanyBean> getAllCompanies() {
		CompanyBean bean= new CompanyBean();
		EntityManagerFactory entityManagerfactory = Persistence.createEntityManagerFactory("TestPersistence");
		EntityManager manager = entityManagerfactory.createEntityManager(); 
		String jpql = "select c from CompanyBean c ";
		
		Query query = manager.createQuery(jpql);
		List<CompanyBean> recordList = query.getResultList();
		if(recordList!=null) {
			for(CompanyBean objects : recordList ) {

				bean.setCompanyId(objects.getCompanyId());
				bean.setCompName(objects.getCompName());
				
                return recordList;
			}
			
		}
		manager.close();
		entityManagerfactory.close();
		return null;
	}

	@Override
	public List<StockBean> getAllStcokInfo() {
		StockBean bean= new StockBean();
		EntityManagerFactory entityManagerfactory = Persistence.createEntityManagerFactory("TestPersistence");
		EntityManager manager = entityManagerfactory.createEntityManager(); 
		String jpql = "select s from StockBean s ";
		
		Query query = manager.createQuery(jpql);
		List<StockBean> recordList = query.getResultList();
		if(recordList!=null) {
			for(StockBean objects : recordList ) {

				bean.setId(objects.getId());
				bean.setCompanyName(objects.getCompanyName());
				bean.setNoOfProducts(objects.getNoOfProducts());
				bean.setCost(objects.getCost());
				bean.setTypeOfStock(objects.getTypeOfStock());
			    recordList.add(bean);
                return recordList;
			}
			
		}
		manager.close();
		entityManagerfactory.close();
		return null;
	}

	@Override
	public List<CompanyManagerBean> getAllCompanyManagerInfo() {
		CompanyManagerBean  bean= new CompanyManagerBean();
		EntityManagerFactory entityManagerfactory = Persistence.createEntityManagerFactory("TestPersistence");
		EntityManager manager = entityManagerfactory.createEntityManager(); 
		String jpql = "select c from CompanyManagerBean c where c.role='companyManager'";
		
		Query query = manager.createQuery(jpql);
		List<CompanyManagerBean> recordList = query.getResultList();
		if(recordList!=null) {
			for(CompanyManagerBean objects : recordList ) {

				bean.setId(objects.getId());
				bean.setName(objects.getName());
				bean.setPhoneNumber(objects.getPhoneNumber());
				bean.setMailId(objects.getMailId());
				bean.setPassword(objects.getPassword());
				bean.setRole(objects.getRole());
                recordList.add(bean);
                return recordList;
			}
			
		}
		manager.close();
		entityManagerfactory.close();
		return null;
	}
		

	@Override
	public boolean addCompany(CompanyBean companyBean) {
//	 companyBean = new CompanyBean();
//	 companyBean.setCompanyId(companyBean.getCompanyId());
//	 companyBean.setCompName(companyBean.getCompName());
//			
		EntityManagerFactory entityManagerFactory= null;
		EntityManager entityManager= null;
		EntityTransaction entityTransaction= null;
		try {
			entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
			entityManager = entityManagerFactory.createEntityManager();
			entityTransaction = entityManager.getTransaction();
			entityTransaction.begin();
			entityManager.persist(companyBean);
			entityTransaction.commit();
			System.out.println("record saved");
			return true;
		}catch(Exception e) {
			e.getMessage();
			entityTransaction.rollback();
		} 
		
		entityManager.close();
		entityManagerFactory.close();
		return false;	
   }

	
	@Override
	public boolean removeCompany(String companyName) {
		EntityManagerFactory entityManagerFactory= null;
		EntityManager entityManager= null;
		EntityTransaction entityTransaction= null;

		try {
			entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
			entityManager = entityManagerFactory.createEntityManager();
		    entityTransaction = entityManager.getTransaction();
			entityTransaction.begin();
			String jpql = "delete CompanyBean c  where c.compName = :comName ";
			 Query query = entityManager.createQuery(jpql);
			 query.setParameter("comName",companyName);
			 int record = query.executeUpdate();
			System.out.println("deleted succefully");
			entityTransaction.commit();
				return true;
			
		  }catch(Exception e) {
	          e.printStackTrace(); 
	     }
			
			entityManager.close();
			entityManagerFactory.close();
			return false;
       }

}
